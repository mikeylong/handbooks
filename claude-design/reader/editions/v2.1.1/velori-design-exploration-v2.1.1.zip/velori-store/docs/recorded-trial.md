# Recorded trial, October 6–7, 2026

The standalone Claude Design beta imported four starter pages. It reported 16 component families and 75 variables, but zero text styles despite 11 in the source. Arimo/Lora were referenced through Google Fonts. The source Product style is 27px; import estimated 28px.

Three alternatives were operated. Direction B was selected for clear review and editing roles. A targeted heading comment persisted. Direct copy edits appeared in the preview but reverted on Save; the same request succeeded through chat.

Configure, details, review and editing retain all choices. Browsing Dock does not select it. The staged unavailable Carry bag offers Dock or None. A 390 × 844 view has no horizontal overflow across Review and Dock details. Native keyboard activation worked; fresh recipient radio-arrow selection and reload retention also worked.

The project ZIP requires network-hosted React/Babel scripts. The standalone HTML embeds scripts and images. Its Retry reloads bundled data. A real missing-resource retry was not tested.

The bounded code-first comparison reused eight exported components and changed Amber to Mint while retaining the other choices. Its Arial/Georgia stacks differ from the Figma route. It did not repeat the complete journey.

Optional Figma continuation restored a selected static Review: 22 styled text nodes, 10 instances, 65 nodes with variable bindings, Arimo/Lora. No prototype connections or choice-state wiring. This is editable design work, not an interactive Figma prototype.

Human task review and final implementation are open. No publication is approved.

## Companion correction, October 7, 2026

Handbook 2.1.1 brings the React app and static editable Figma answer key into line with the Add to cart exercise. The React app now saves one configured robot, restores it for editing, updates it without duplication and retains it across a same-tab reload. The Figma answer has Review with Add to cart and a Cart confirmation frame, each with 24 styled text nodes, 10 component instances and 70 variable-bound nodes. Both native frames remain static, with no prototype connections or choice-state wiring. This is separate from the original trial above; no new Claude Design generation trial or human usability review is claimed.
