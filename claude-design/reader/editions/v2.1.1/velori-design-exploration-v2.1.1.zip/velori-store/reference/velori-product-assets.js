'use strict';
window.VELORI_PRODUCT_ASSETS = {
  "products": {
    "chalk-dock": "assets/velori/chalk-dock.png?v=69199dfe293b",
    "chalk-bag": "assets/velori/chalk-bag.png?v=d945d3ccda8a",
    "chalk-none": "assets/velori/chalk-none.png?v=6fce5c782060",
    "pebble-dock": "assets/velori/pebble-dock.png?v=0b387ab55f71",
    "pebble-bag": "assets/velori/pebble-bag-shell-v2.png?v=5f5db0d9196c",
    "pebble-none": "assets/velori/pebble-none.png?v=f15487166b5a",
    "graphite-dock": "assets/velori/graphite-dock.png?v=bec2e3123c9c",
    "graphite-bag": "assets/velori/graphite-bag-shell-v2.png?v=469c51fcda41",
    "graphite-none": "assets/velori/graphite-none.png?v=6dd86f8ef92d"
  },
  "faces": {
    "friendly": "assets/velori/face-friendly.png?v=a6c5ca57ed77",
    "simple": "assets/velori/face-simple.png?v=e3c23b6a47a8"
  },
  "alignment": {},
  "bagComposite": {
    "base": "assets/velori/chalk-bag.png?v=d945d3ccda8a",
    "robotMask": "assets/velori/bag-robot-mask.svg?v=5c603119ad76"
  },
  "dockLayer": "assets/velori/dock-layer.png?v=5fa746a72444"
};
