import * as React from 'react';

/**
 * AccessoryPhoto — from velori-store-handbook-sample@0.1.0.
 */
export interface AccessoryPhotoProps {
accessory: 'dock' | 'bag';
}

export declare const AccessoryPhoto: React.ComponentType<AccessoryPhotoProps>;
