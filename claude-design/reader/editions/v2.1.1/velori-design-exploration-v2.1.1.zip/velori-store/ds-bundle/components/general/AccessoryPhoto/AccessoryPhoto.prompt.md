AccessoryPhoto from velori-store-handbook-sample. Use via `window.Velori.AccessoryPhoto` (bundle loaded from the root `_ds_bundle.js`).

## Props

```ts
interface AccessoryPhotoProps {
accessory: 'dock' | 'bag';
}
```

## Examples

### Dock

```jsx
() => <div style={{ width: 544 }}><AccessoryPhoto accessory="dock" /></div>
```

### CarryBag

```jsx
() => <div style={{ width: 544 }}><AccessoryPhoto accessory="bag" /></div>
```
