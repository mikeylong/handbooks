PrimaryButton from velori-store-handbook-sample. Use via `window.Velori.PrimaryButton` (bundle loaded from the root `_ds_bundle.js`).

## Props

```ts
interface PrimaryButtonProps {
children: React.ReactNode; onClick?: () => void; id?: string;
}
```

## Examples

### Continue

```jsx
() => <div style={{ width: 360 }}><PrimaryButton>Continue</PrimaryButton></div>
```

### EditConfiguration

```jsx
() => <div style={{ width: 360 }}><PrimaryButton>Edit configuration</PrimaryButton></div>
```
