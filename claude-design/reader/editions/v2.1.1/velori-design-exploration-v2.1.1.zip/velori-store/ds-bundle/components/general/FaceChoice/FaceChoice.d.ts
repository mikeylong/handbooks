import * as React from 'react';

/**
 * FaceChoice — from velori-store-handbook-sample@0.1.0.
 */
export interface FaceChoiceProps {
value: 'friendly' | 'simple'; onChange: (value: 'friendly' | 'simple') => void;
}

export declare const FaceChoice: React.ComponentType<FaceChoiceProps>;
