Brand from velori-store-handbook-sample. Use via `window.Velori.Brand` (bundle loaded from the root `_ds_bundle.js`).

## Examples

### Default

```jsx
() => <Brand />
```
