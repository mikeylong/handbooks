ExpressionSelect from velori-store-handbook-sample. Use via `window.Velori.ExpressionSelect` (bundle loaded from the root `_ds_bundle.js`).

## Props

```ts
interface ExpressionSelectProps {
value: 'white' | 'mint' | 'blue' | 'amber'; onChange: (value: 'white' | 'mint' | 'blue' | 'amber') => void;
}
```

## Examples

### White

```jsx
() => <div style={{ width: 360 }}><ExpressionSelect value="white" onChange={noop} /></div>
```

### Mint

```jsx
() => <div style={{ width: 360 }}><ExpressionSelect value="mint" onChange={noop} /></div>
```

### Amber

```jsx
() => <div style={{ width: 360 }}><ExpressionSelect value="amber" onChange={noop} /></div>
```
