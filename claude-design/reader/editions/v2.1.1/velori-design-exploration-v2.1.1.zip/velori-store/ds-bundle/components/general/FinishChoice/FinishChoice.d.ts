import * as React from 'react';

/**
 * FinishChoice — from velori-store-handbook-sample@0.1.0.
 */
export interface FinishChoiceProps {
value: 'chalk' | 'pebble' | 'graphite'; onChange: (value: 'chalk' | 'pebble' | 'graphite') => void;
}

export declare const FinishChoice: React.ComponentType<FinishChoiceProps>;
