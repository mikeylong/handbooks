import * as React from 'react';

/**
 * ConfigurationSummary — from velori-store-handbook-sample@0.1.0.
 */
export interface ConfigurationSummaryProps {
configuration: { shell: 'chalk' | 'pebble' | 'graphite'; face: 'friendly' | 'simple'; color: 'white' | 'mint' | 'blue' | 'amber'; accessory: 'dock' | 'bag' | 'none' };
}

export declare const ConfigurationSummary: React.ComponentType<ConfigurationSummaryProps>;
