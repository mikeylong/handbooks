SelectionMark from velori-store-handbook-sample. Use via `window.Velori.SelectionMark` (bundle loaded from the root `_ds_bundle.js`).

## Examples

### OnChosenTile

```jsx
() => <div style={tile}>Graphite<SelectionMark /></div>
```
