FaceChoice from velori-store-handbook-sample. Use via `window.Velori.FaceChoice` (bundle loaded from the root `_ds_bundle.js`).

## Props

```ts
interface FaceChoiceProps {
value: 'friendly' | 'simple'; onChange: (value: 'friendly' | 'simple') => void;
}
```

## Examples

### Default

```jsx
() => <div style={{ width: 420 }}><FaceChoice value="friendly" onChange={noop} /></div>
```

### AlternateSelected

```jsx
() => <div style={{ width: 420 }}><FaceChoice value="simple" onChange={noop} /></div>
```
