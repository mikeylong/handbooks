import * as React from 'react';

/**
 * PrimaryButton — from velori-store-handbook-sample@0.1.0.
 */
export interface PrimaryButtonProps {
children: React.ReactNode; onClick?: () => void; id?: string;
}

export declare const PrimaryButton: React.ComponentType<PrimaryButtonProps>;
