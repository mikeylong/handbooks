// Re-export of velori-store-handbook-sample@0.1.0 ProductPreview. Implementation is in the root _ds_bundle.js (window.Velori).
Object.assign(window, { ProductPreview: window.Velori.ProductPreview });
