ProductPreview from velori-store-handbook-sample. Use via `window.Velori.ProductPreview` (bundle loaded from the root `_ds_bundle.js`).

## Props

```ts
interface ProductPreviewProps {
configuration: { shell: 'chalk' | 'pebble' | 'graphite'; face: 'friendly' | 'simple'; color: 'white' | 'mint' | 'blue' | 'amber'; accessory: 'dock' | 'bag' | 'none' }; unavailable?: boolean; onDetails?: () => void;
}
```

## Examples

### Default

```jsx
() => <div style={{ width: 400 }}><ProductPreview configuration={{ shell: 'chalk', face: 'friendly', color: 'white', accessory: 'dock' }} /></div>
```

### GraphiteCarryBagMint

```jsx
() => <div style={{ width: 400 }}><ProductPreview configuration={{ shell: 'graphite', face: 'simple', color: 'mint', accessory: 'bag' }} /></div>
```

### ImageUnavailable

```jsx
() => <div style={{ width: 400 }}><ProductPreview unavailable configuration={{ shell: 'chalk', face: 'friendly', color: 'white', accessory: 'dock' }} /></div>
```
