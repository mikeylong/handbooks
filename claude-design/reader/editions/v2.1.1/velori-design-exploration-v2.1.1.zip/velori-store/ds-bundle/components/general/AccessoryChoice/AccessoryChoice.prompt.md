AccessoryChoice from velori-store-handbook-sample. Use via `window.Velori.AccessoryChoice` (bundle loaded from the root `_ds_bundle.js`).

## Props

```ts
interface AccessoryChoiceProps {
value: 'dock' | 'bag' | 'none'; onChange: (value: 'dock' | 'bag' | 'none') => void;
}
```

## Examples

### Default

```jsx
() => <div style={{ width: 420 }}><AccessoryChoice value="dock" onChange={noop} /></div>
```

### AlternateSelected

```jsx
() => <div style={{ width: 420 }}><AccessoryChoice value="bag" onChange={noop} /></div>
```
