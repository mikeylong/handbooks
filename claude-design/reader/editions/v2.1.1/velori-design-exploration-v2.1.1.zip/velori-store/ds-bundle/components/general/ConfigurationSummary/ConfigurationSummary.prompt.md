ConfigurationSummary from velori-store-handbook-sample. Use via `window.Velori.ConfigurationSummary` (bundle loaded from the root `_ds_bundle.js`).

## Props

```ts
interface ConfigurationSummaryProps {
configuration: { shell: 'chalk' | 'pebble' | 'graphite'; face: 'friendly' | 'simple'; color: 'white' | 'mint' | 'blue' | 'amber'; accessory: 'dock' | 'bag' | 'none' };
}
```

## Examples

### Default

```jsx
() => <div style={{ width: 400 }}><ConfigurationSummary configuration={{ shell: 'chalk', face: 'friendly', color: 'white', accessory: 'dock' }} /></div>
```

### Customized

```jsx
() => <div style={{ width: 400 }}><ConfigurationSummary configuration={{ shell: 'graphite', face: 'simple', color: 'mint', accessory: 'bag' }} /></div>
```
