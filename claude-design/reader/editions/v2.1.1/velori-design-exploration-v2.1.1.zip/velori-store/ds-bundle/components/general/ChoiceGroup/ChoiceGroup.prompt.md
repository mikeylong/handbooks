ChoiceGroup from velori-store-handbook-sample. Use via `window.Velori.ChoiceGroup` (bundle loaded from the root `_ds_bundle.js`).

## Props

```ts
interface ChoiceGroupProps {
group: 'shell' | 'face' | 'accessory'; value: string; onChange: (value: string) => void;
}
```

## Examples

### Shell

```jsx
() => <div style={{ width: 420 }}><ChoiceGroup group="shell" value="pebble" onChange={noop} /></div>
```

### Face

```jsx
() => <div style={{ width: 420 }}><ChoiceGroup group="face" value="friendly" onChange={noop} /></div>
```

### Accessory

```jsx
() => <div style={{ width: 420 }}><ChoiceGroup group="accessory" value="none" onChange={noop} /></div>
```
