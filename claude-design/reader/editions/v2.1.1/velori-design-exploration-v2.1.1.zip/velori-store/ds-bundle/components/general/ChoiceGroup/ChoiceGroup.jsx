// Re-export of velori-store-handbook-sample@0.1.0 ChoiceGroup. Implementation is in the root _ds_bundle.js (window.Velori).
Object.assign(window, { ChoiceGroup: window.Velori.ChoiceGroup });
