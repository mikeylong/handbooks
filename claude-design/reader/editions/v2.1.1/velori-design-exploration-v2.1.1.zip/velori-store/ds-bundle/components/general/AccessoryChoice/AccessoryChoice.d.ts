import * as React from 'react';

/**
 * AccessoryChoice — from velori-store-handbook-sample@0.1.0.
 */
export interface AccessoryChoiceProps {
value: 'dock' | 'bag' | 'none'; onChange: (value: 'dock' | 'bag' | 'none') => void;
}

export declare const AccessoryChoice: React.ComponentType<AccessoryChoiceProps>;
