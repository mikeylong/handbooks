StoreHeader from velori-store-handbook-sample. Use via `window.Velori.StoreHeader` (bundle loaded from the root `_ds_bundle.js`).

## Props

```ts
interface StoreHeaderProps {
review?: boolean; onBack?: () => void;
}
```

## Examples

### ConfigureStep

```jsx
() => <div style={{ width: 760 }}><StoreHeader /></div>
```

### ReviewStep

```jsx
() => <div style={{ width: 760 }}><StoreHeader review /></div>
```

### WithBackLink

```jsx
() => <div style={{ width: 760 }}><StoreHeader onBack={() => {}} /></div>
```
