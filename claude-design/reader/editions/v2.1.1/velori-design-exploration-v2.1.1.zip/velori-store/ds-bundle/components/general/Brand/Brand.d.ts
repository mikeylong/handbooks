import * as React from 'react';

/**
 * Brand — from velori-store-handbook-sample@0.1.0.
 */
export interface BrandProps {
  [key: string]: unknown;
}

export declare const Brand: React.ComponentType<BrandProps>;
