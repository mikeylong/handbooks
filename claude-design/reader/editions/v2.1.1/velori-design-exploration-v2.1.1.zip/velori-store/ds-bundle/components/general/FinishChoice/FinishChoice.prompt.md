FinishChoice from velori-store-handbook-sample. Use via `window.Velori.FinishChoice` (bundle loaded from the root `_ds_bundle.js`).

## Props

```ts
interface FinishChoiceProps {
value: 'chalk' | 'pebble' | 'graphite'; onChange: (value: 'chalk' | 'pebble' | 'graphite') => void;
}
```

## Examples

### Default

```jsx
() => <div style={{ width: 420 }}><FinishChoice value="chalk" onChange={noop} /></div>
```

### AlternateSelected

```jsx
() => <div style={{ width: 420 }}><FinishChoice value="graphite" onChange={noop} /></div>
```
