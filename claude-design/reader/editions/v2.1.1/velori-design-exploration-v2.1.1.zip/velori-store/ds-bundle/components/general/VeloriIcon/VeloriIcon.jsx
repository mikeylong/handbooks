// Re-export of velori-store-handbook-sample@0.1.0 VeloriIcon. Implementation is in the root _ds_bundle.js (window.Velori).
Object.assign(window, { VeloriIcon: window.Velori.VeloriIcon });
