import * as React from 'react';

/**
 * VeloriIcon — from velori-store-handbook-sample@0.1.0.
 */
export interface VeloriIconProps {
name: 'check' | 'chevron' | 'friendly' | 'simple'; className?: string; [svgAttr: string]: unknown;
}

export declare const VeloriIcon: React.ComponentType<VeloriIconProps>;
