import * as React from 'react';

/**
 * ChoiceGroup — from velori-store-handbook-sample@0.1.0.
 */
export interface ChoiceGroupProps {
group: 'shell' | 'face' | 'accessory'; value: string; onChange: (value: string) => void;
}

export declare const ChoiceGroup: React.ComponentType<ChoiceGroupProps>;
