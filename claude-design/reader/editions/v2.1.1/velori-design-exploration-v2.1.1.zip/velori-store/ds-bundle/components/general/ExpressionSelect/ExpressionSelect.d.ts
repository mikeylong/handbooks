import * as React from 'react';

/**
 * ExpressionSelect — from velori-store-handbook-sample@0.1.0.
 */
export interface ExpressionSelectProps {
value: 'white' | 'mint' | 'blue' | 'amber'; onChange: (value: 'white' | 'mint' | 'blue' | 'amber') => void;
}

export declare const ExpressionSelect: React.ComponentType<ExpressionSelectProps>;
