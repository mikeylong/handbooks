VeloriIcon from velori-store-handbook-sample. Use via `window.Velori.VeloriIcon` (bundle loaded from the root `_ds_bundle.js`).

## Props

```ts
interface VeloriIconProps {
name: 'check' | 'chevron' | 'friendly' | 'simple'; className?: string; [svgAttr: string]: unknown;
}
```

## Examples

### AllIcons

```jsx
() => (
  <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, max-content)', gap: '16px 32px' }}>
    {(['check', 'chevron', 'friendly', 'simple'] as const).map((n) => (
      <div key={n} style={cell}><VeloriIcon name={n} /><span>{n}</span></div>
    ))}
  </div>
)
```

### FaceExpressions

```jsx
() => (
  <div style={{ display: 'flex', gap: 24, color: 'var(--velori-color-ink)' }}>
    <VeloriIcon name="friendly" style={{ width: 48, height: 48 }} />
    <VeloriIcon name="simple" style={{ width: 48, height: 48 }} />
  </div>
)
```
