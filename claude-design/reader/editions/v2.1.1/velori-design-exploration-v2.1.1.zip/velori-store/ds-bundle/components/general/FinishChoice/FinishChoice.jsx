// Re-export of velori-store-handbook-sample@0.1.0 FinishChoice. Implementation is in the root _ds_bundle.js (window.Velori).
Object.assign(window, { FinishChoice: window.Velori.FinishChoice });
