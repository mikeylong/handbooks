import * as React from 'react';

/**
 * ProductPreview — from velori-store-handbook-sample@0.1.0.
 */
export interface ProductPreviewProps {
configuration: { shell: 'chalk' | 'pebble' | 'graphite'; face: 'friendly' | 'simple'; color: 'white' | 'mint' | 'blue' | 'amber'; accessory: 'dock' | 'bag' | 'none' }; unavailable?: boolean; onDetails?: () => void;
}

export declare const ProductPreview: React.ComponentType<ProductPreviewProps>;
