import * as React from 'react';

/**
 * StoreHeader — from velori-store-handbook-sample@0.1.0.
 */
export interface StoreHeaderProps {
review?: boolean; onBack?: () => void;
}

export declare const StoreHeader: React.ComponentType<StoreHeaderProps>;
