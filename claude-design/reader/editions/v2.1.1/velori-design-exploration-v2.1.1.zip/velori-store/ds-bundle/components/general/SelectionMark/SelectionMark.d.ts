import * as React from 'react';

/**
 * SelectionMark — from velori-store-handbook-sample@0.1.0.
 */
export interface SelectionMarkProps {
  [key: string]: unknown;
}

export declare const SelectionMark: React.ComponentType<SelectionMarkProps>;
