/* @ds-bundle: {"namespace":"Velori","components":[{"name":"AccessoryChoice","sourcePath":"components/general/AccessoryChoice/AccessoryChoice.jsx"},{"name":"AccessoryPhoto","sourcePath":"components/general/AccessoryPhoto/AccessoryPhoto.jsx"},{"name":"Brand","sourcePath":"components/general/Brand/Brand.jsx"},{"name":"ChoiceGroup","sourcePath":"components/general/ChoiceGroup/ChoiceGroup.jsx"},{"name":"ConfigurationSummary","sourcePath":"components/general/ConfigurationSummary/ConfigurationSummary.jsx"},{"name":"ExpressionSelect","sourcePath":"components/general/ExpressionSelect/ExpressionSelect.jsx"},{"name":"FaceChoice","sourcePath":"components/general/FaceChoice/FaceChoice.jsx"},{"name":"FinishChoice","sourcePath":"components/general/FinishChoice/FinishChoice.jsx"},{"name":"PrimaryButton","sourcePath":"components/general/PrimaryButton/PrimaryButton.jsx"},{"name":"ProductPreview","sourcePath":"components/general/ProductPreview/ProductPreview.jsx"},{"name":"SelectionMark","sourcePath":"components/general/SelectionMark/SelectionMark.jsx"},{"name":"StoreHeader","sourcePath":"components/general/StoreHeader/StoreHeader.jsx"},{"name":"VeloriIcon","sourcePath":"components/general/VeloriIcon/VeloriIcon.jsx"}],"sourceHashes":{"components/general/AccessoryChoice/AccessoryChoice.jsx":"26f829590471","components/general/AccessoryChoice/AccessoryChoice.d.ts":"8c02ea838106","components/general/AccessoryChoice/AccessoryChoice.prompt.md":"6808f0d09022","components/general/AccessoryPhoto/AccessoryPhoto.jsx":"14256b72f3cb","components/general/AccessoryPhoto/AccessoryPhoto.d.ts":"13b7bd27e4e2","components/general/AccessoryPhoto/AccessoryPhoto.prompt.md":"1992a29258f7","components/general/Brand/Brand.jsx":"3bbbd8afe4f3","components/general/Brand/Brand.d.ts":"a64e97537231","components/general/Brand/Brand.prompt.md":"3435966dcf44","components/general/ChoiceGroup/ChoiceGroup.jsx":"814fe8e90bdf","components/general/ChoiceGroup/ChoiceGroup.d.ts":"b01c0b0262e1","components/general/ChoiceGroup/ChoiceGroup.prompt.md":"7546c206d9cd","components/general/ConfigurationSummary/ConfigurationSummary.jsx":"e7bef7b364a6","components/general/ConfigurationSummary/ConfigurationSummary.d.ts":"3720b6081f11","components/general/ConfigurationSummary/ConfigurationSummary.prompt.md":"6f3365aa7ded","components/general/ExpressionSelect/ExpressionSelect.jsx":"36a5d14d9526","components/general/ExpressionSelect/ExpressionSelect.d.ts":"b29506145f8e","components/general/ExpressionSelect/ExpressionSelect.prompt.md":"353dbda785c3","components/general/FaceChoice/FaceChoice.jsx":"7857b19d079d","components/general/FaceChoice/FaceChoice.d.ts":"2f6a055c97dc","components/general/FaceChoice/FaceChoice.prompt.md":"4fd50dfd60ba","components/general/FinishChoice/FinishChoice.jsx":"c6b7076347db","components/general/FinishChoice/FinishChoice.d.ts":"354cb322f37b","components/general/FinishChoice/FinishChoice.prompt.md":"aa889e36c290","components/general/PrimaryButton/PrimaryButton.jsx":"5592cb28b20c","components/general/PrimaryButton/PrimaryButton.d.ts":"50cb619b4944","components/general/PrimaryButton/PrimaryButton.prompt.md":"1a0106258d26","components/general/ProductPreview/ProductPreview.jsx":"54f0bfd2a698","components/general/ProductPreview/ProductPreview.d.ts":"cce8e39e5ade","components/general/ProductPreview/ProductPreview.prompt.md":"56af2313089c","components/general/SelectionMark/SelectionMark.jsx":"5af52e664c1f","components/general/SelectionMark/SelectionMark.d.ts":"e6066d00dba3","components/general/SelectionMark/SelectionMark.prompt.md":"3f899a6a39d1","components/general/StoreHeader/StoreHeader.jsx":"ead3197e4091","components/general/StoreHeader/StoreHeader.d.ts":"d3bc683ff819","components/general/StoreHeader/StoreHeader.prompt.md":"a2964c083aed","components/general/VeloriIcon/VeloriIcon.jsx":"afaa5987d025","components/general/VeloriIcon/VeloriIcon.d.ts":"afaa99a9e283","components/general/VeloriIcon/VeloriIcon.prompt.md":"b5bd9b83833d"},"inlinedExternals":[],"builtBy":"cc-design-sync"} */
var Velori = (() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __esm = (fn, res, err) => function __init() {
    if (err) throw err[0];
    try {
      return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
    } catch (e) {
      throw err = [e], e;
    }
  };
  var __commonJS = (cb, mod) => function __require() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // <define:import.meta.env>
  var define_import_meta_env_default;
  var init_define_import_meta_env = __esm({
    "<define:import.meta.env>"() {
      define_import_meta_env_default = { MODE: "development", DEV: true, PROD: false, SSR: false, BASE_URL: "/" };
    }
  });

  // shim:react-shim
  var require_react_shim = __commonJS({
    "shim:react-shim"(exports, module) {
      init_define_import_meta_env();
      var R = window.React;
      function np(p, k) {
        var o = {};
        for (var x in p) if (x !== "children") o[x] = p[x];
        if (k !== void 0) o.key = k;
        return o;
      }
      function jsx(t, p, k) {
        var c = p && p.children;
        return c === void 0 ? R.createElement(t, np(p, k)) : R.createElement(t, np(p, k), c);
      }
      function jsxs(t, p, k) {
        return R.createElement.apply(R, [t, np(p, k)].concat(p.children));
      }
      module.exports = R;
      module.exports.jsx = jsx;
      module.exports.jsxs = jsxs;
      module.exports.jsxDEV = function(t, p, k, s) {
        return (s ? jsxs : jsx)(t, p, k);
      };
      module.exports.Fragment = R.Fragment;
    }
  });

  // .design-sync/host-entry.mjs
  var host_entry_exports = {};
  __export(host_entry_exports, {
    AccessoryChoice: () => AccessoryChoice,
    AccessoryPhoto: () => AccessoryPhoto,
    Brand: () => Brand,
    ChoiceGroup: () => ChoiceGroup,
    ConfigurationSummary: () => ConfigurationSummary,
    ExpressionSelect: () => ExpressionSelect,
    FaceChoice: () => FaceChoice,
    FinishChoice: () => FinishChoice,
    PrimaryButton: () => PrimaryButton,
    ProductPreview: () => ProductPreview,
    SelectionMark: () => SelectionMark,
    StoreHeader: () => StoreHeader,
    VeloriIcon: () => VeloriIcon
  });
  init_define_import_meta_env();

  // src/library.jsx
  init_define_import_meta_env();
  var import_react = __toESM(require_react_shim(), 1);

  // src/model.mjs
  init_define_import_meta_env();
  var DEFAULTS = Object.freeze({ shell: "chalk", face: "friendly", color: "white", accessory: "dock" });
  var CHOICES = Object.freeze({ shell: ["chalk", "pebble", "graphite"], face: ["friendly", "simple"], color: ["white", "mint", "blue", "amber"], accessory: ["dock", "bag", "none"] });
  var LABELS = { chalk: "Chalk", pebble: "Pebble", graphite: "Graphite", friendly: "Friendly", simple: "Simple", white: "White", mint: "Mint", blue: "Blue", amber: "Amber", dock: "Dock", bag: "Carry bag", none: "None" };
  var COLORS = { white: "#f4f6f2", mint: "#78ebc8", blue: "#80c8ff", amber: "#ffcc70", chalk: "#e6e8e5", pebble: "#a7aaa9", graphite: "#434b50" };
  function caption(c) {
    return `${LABELS[c.shell]} shell \xB7 ${LABELS[c.face]} face \xB7 ${LABELS[c.color]} \xB7 ${LABELS[c.accessory]}`;
  }
  function productAssets(c) {
    const bag = c.accessory === "bag";
    const file = bag && c.shell !== "chalk" ? `${c.shell}-bag-shell-v2.png` : `${c.shell}-${c.accessory}.png`;
    return { photo: `assets/velori/${bag ? "chalk-bag.png" : file}`, shell: bag && c.shell !== "chalk" ? `assets/velori/${file}` : null, robotMask: bag && c.shell !== "chalk" ? "assets/velori/bag-robot-mask.svg" : null, faceMask: `assets/velori/face-${c.face}.png` };
  }
  var FIXTURES = Object.freeze({ purpleContinue: "purple-continue", tightAccessories: "accessory-gap-8" });

  // src/library.jsx
  var assetUrl = (path) => new URL(define_import_meta_env_default.BASE_URL + path, document.baseURI).href;
  function VeloriIcon({ name, ...props }) {
    return /* @__PURE__ */ import_react.default.createElement("svg", { viewBox: "0 0 24 24", className: "velori-icon", "aria-hidden": "true", focusable: "false", ...props }, name === "check" ? /* @__PURE__ */ import_react.default.createElement("path", { d: "M5 12.5 9.5 17 19 7" }) : name === "chevron" ? /* @__PURE__ */ import_react.default.createElement("path", { d: "m5 9 7 7 7-7" }) : name === "friendly" ? /* @__PURE__ */ import_react.default.createElement("path", { d: "M5 8q2-3 4 0m6 0q2-3 4 0M9 14q3 3 6 0" }) : /* @__PURE__ */ import_react.default.createElement(import_react.default.Fragment, null, /* @__PURE__ */ import_react.default.createElement("circle", { cx: "7", cy: "9", r: "1" }), /* @__PURE__ */ import_react.default.createElement("circle", { cx: "17", cy: "9", r: "1" }), /* @__PURE__ */ import_react.default.createElement("path", { d: "M9 15h6" })));
  }
  function SelectionMark() {
    return /* @__PURE__ */ import_react.default.createElement("span", { className: "selection-mark" }, /* @__PURE__ */ import_react.default.createElement(VeloriIcon, { name: "check" }));
  }
  function PrimaryButton({ fixture, ...props }) {
    return /* @__PURE__ */ import_react.default.createElement("button", { type: "button", className: `primary ${fixture === "purple-continue" ? "fixture-purple" : ""}`, ...props });
  }
  function ChoiceGroup({ group, value, onChange }) {
    const face = group === "face";
    return /* @__PURE__ */ import_react.default.createElement("div", { role: "group", "aria-label": { shell: "Shell finish", face: "Face display", accessory: "Accessories" }[group], className: `choices ${group}` }, CHOICES[group].map((option) => /* @__PURE__ */ import_react.default.createElement("button", { type: "button", key: option, "data-choice": `${group}:${option}`, "aria-pressed": value === option, className: value === option ? "chosen" : "", onClick: () => onChange(option) }, group === "shell" && /* @__PURE__ */ import_react.default.createElement("span", { className: "swatch", style: { background: COLORS[option] } }), face && /* @__PURE__ */ import_react.default.createElement(VeloriIcon, { name: option }), /* @__PURE__ */ import_react.default.createElement("span", { className: "choice-name" }, LABELS[option], value === option && /* @__PURE__ */ import_react.default.createElement(SelectionMark, null)))));
  }
  var FinishChoice = (props) => /* @__PURE__ */ import_react.default.createElement(ChoiceGroup, { group: "shell", ...props });
  var FaceChoice = (props) => /* @__PURE__ */ import_react.default.createElement(ChoiceGroup, { group: "face", ...props });
  var AccessoryChoice = (props) => /* @__PURE__ */ import_react.default.createElement(ChoiceGroup, { group: "accessory", ...props });
  function ExpressionSelect({ value, onChange }) {
    const id = (0, import_react.useId)(), wrap = (0, import_react.useRef)(null), trigger = (0, import_react.useRef)(null), type = (0, import_react.useRef)({ text: "", at: 0 });
    const [open, setOpen] = (0, import_react.useState)(false), [active, setActive] = (0, import_react.useState)(0);
    const selected = CHOICES.color.indexOf(value);
    (0, import_react.useEffect)(() => {
      const outside = (e) => {
        if (!wrap.current?.contains(e.target)) setOpen(false);
      };
      document.addEventListener("pointerdown", outside);
      return () => document.removeEventListener("pointerdown", outside);
    }, []);
    const show = () => {
      setActive(selected);
      setOpen(true);
    };
    const commit = (i) => {
      onChange(CHOICES.color[i]);
      setOpen(false);
      trigger.current.focus();
    };
    const key = (e) => {
      const k = e.key;
      if (k === "Tab") {
        setOpen(false);
        return;
      }
      if (k === "Escape") {
        e.preventDefault();
        setOpen(false);
        return;
      }
      if (e.altKey && k === "ArrowUp") {
        e.preventDefault();
        setOpen(false);
        return;
      }
      if (["Enter", " ", "ArrowDown", "ArrowUp", "Home", "End"].includes(k)) {
        e.preventDefault();
        if (k === "Enter" || k === " ") {
          open ? commit(active) : show();
          return;
        }
        if (!open) {
          show();
          if (k === "Home") setActive(0);
          if (k === "End") setActive(3);
          return;
        }
        setActive(k === "Home" ? 0 : k === "End" ? 3 : k === "ArrowDown" ? Math.min(3, active + 1) : Math.max(0, active - 1));
        return;
      }
      if (k.length === 1 && !e.ctrlKey && !e.metaKey && !e.altKey) {
        e.preventDefault();
        const now = Date.now();
        type.current = { text: (now - type.current.at < 700 ? type.current.text : "") + k.toLowerCase(), at: now };
        const i = CHOICES.color.findIndex((c) => LABELS[c].toLowerCase().startsWith(type.current.text));
        if (i >= 0) {
          setActive(i);
          setOpen(true);
        }
      }
    };
    return /* @__PURE__ */ import_react.default.createElement("div", { className: "expression-select", ref: wrap, onBlur: (e) => {
      if (!e.currentTarget.contains(e.relatedTarget)) setOpen(false);
    } }, /* @__PURE__ */ import_react.default.createElement("label", { id: `${id}-label` }, "Face expression color"), /* @__PURE__ */ import_react.default.createElement("button", { type: "button", id: "expression-select", ref: trigger, className: "select-trigger", role: "combobox", "aria-labelledby": `${id}-label ${id}-value`, "aria-controls": `${id}-list`, "aria-haspopup": "listbox", "aria-expanded": open, "aria-activedescendant": open ? `${id}-${active}` : void 0, onClick: () => open ? setOpen(false) : show(), onKeyDown: key }, /* @__PURE__ */ import_react.default.createElement("span", { className: "color-dot", style: { background: COLORS[value] } }), /* @__PURE__ */ import_react.default.createElement("span", { id: `${id}-value` }, LABELS[value]), /* @__PURE__ */ import_react.default.createElement(VeloriIcon, { name: "chevron", className: "select-arrow" })), open && /* @__PURE__ */ import_react.default.createElement("div", { className: "select-menu", id: `${id}-list`, role: "listbox", "aria-labelledby": `${id}-label` }, CHOICES.color.map((c, i) => /* @__PURE__ */ import_react.default.createElement("div", { key: c, id: `${id}-${i}`, role: "option", "aria-selected": c === value, "data-active": i === active, onPointerMove: () => setActive(i), onMouseDown: (e) => e.preventDefault(), onClick: () => commit(i) }, /* @__PURE__ */ import_react.default.createElement("span", { className: "color-dot", style: { background: COLORS[c] } }), /* @__PURE__ */ import_react.default.createElement("span", null, LABELS[c]), c === value && /* @__PURE__ */ import_react.default.createElement(VeloriIcon, { name: "check" })))));
  }
  function ProductPreview({ configuration, unavailable = false, onDetails }) {
    const [status, setStatus] = (0, import_react.useState)("loading"), [ready, setReady] = (0, import_react.useState)(null), [attempt, setAttempt] = (0, import_react.useState)(0);
    const c = configuration, a = productAssets(c), signature = JSON.stringify(a);
    (0, import_react.useEffect)(() => {
      let current = true;
      setStatus("loading");
      setReady(null);
      const load = (path) => new Promise((resolve, reject) => {
        const i = new Image();
        i.onload = () => i.decode().then(resolve, reject);
        i.onerror = reject;
        i.src = assetUrl(path);
      });
      Promise.all(Object.values(a).filter(Boolean).map(load)).then(() => {
        if (current) {
          setReady(a);
          setStatus("ready");
        }
      }, () => {
        if (current) setStatus("error");
      });
      return () => {
        current = false;
      };
    }, [signature, attempt]);
    const failed = unavailable || status === "error";
    return /* @__PURE__ */ import_react.default.createElement("div", { className: "product-view", "aria-busy": !failed && status === "loading", "data-image-state": failed ? "error" : status }, ready && !failed && /* @__PURE__ */ import_react.default.createElement("div", { className: "product-render", "data-configuration": caption(c) }, /* @__PURE__ */ import_react.default.createElement("img", { className: "product-photo", src: assetUrl(ready.photo), width: "1254", height: "1254", alt: `Velori with ${caption(c)}` }), ready.shell && /* @__PURE__ */ import_react.default.createElement("img", { className: "product-shell", src: assetUrl(ready.shell), style: { "--robot-mask": `url("${assetUrl(ready.robotMask)}")` }, alt: "" }), /* @__PURE__ */ import_react.default.createElement("div", { className: "face-light", "data-face": c.face, "aria-hidden": "true" }, /* @__PURE__ */ import_react.default.createElement("span", { className: "expression-layer", style: { "--face-mask": `url("${assetUrl(ready.faceMask)}")`, background: COLORS[c.color] } }))), failed ? /* @__PURE__ */ import_react.default.createElement("div", { className: "image-placeholder", role: "status" }, /* @__PURE__ */ import_react.default.createElement("strong", null, "Product image unavailable."), /* @__PURE__ */ import_react.default.createElement("p", null, "Your choices are still here. You can keep editing."), !unavailable && /* @__PURE__ */ import_react.default.createElement("button", { type: "button", onClick: () => setAttempt((n) => n + 1) }, "Retry image")) : status === "loading" && /* @__PURE__ */ import_react.default.createElement("p", { className: "image-placeholder", role: "status" }, "Loading your Velori\u2026"), onDetails && /* @__PURE__ */ import_react.default.createElement("button", { id: "accessory-details", type: "button", className: "details-link", onClick: onDetails }, "View accessory details"));
  }
  function Brand() {
    return /* @__PURE__ */ import_react.default.createElement("div", { className: "brand" }, /* @__PURE__ */ import_react.default.createElement("b", null, "VELORI"), /* @__PURE__ */ import_react.default.createElement("span", null, "Personal robotics"));
  }
  function StoreHeader({ review = false, onBack }) {
    return /* @__PURE__ */ import_react.default.createElement("header", { className: "store-header" }, /* @__PURE__ */ import_react.default.createElement(Brand, null), onBack ? /* @__PURE__ */ import_react.default.createElement("button", { className: "back-link", type: "button", onClick: onBack }, "\u2190 Back to configurator") : /* @__PURE__ */ import_react.default.createElement("ol", { className: "steps", "aria-label": "Configuration steps" }, /* @__PURE__ */ import_react.default.createElement("li", { "aria-current": !review ? "step" : void 0 }, /* @__PURE__ */ import_react.default.createElement("span", null, "1"), "Configure"), /* @__PURE__ */ import_react.default.createElement("li", { "aria-current": review ? "step" : void 0 }, /* @__PURE__ */ import_react.default.createElement("span", null, "2"), "Review")));
  }
  function ConfigurationSummary({ configuration }) {
    return /* @__PURE__ */ import_react.default.createElement("dl", { className: "summary" }, Object.entries({ shell: "Shell finish", face: "Face display", color: "Face expression color", accessory: "Accessories" }).map(([key, label]) => /* @__PURE__ */ import_react.default.createElement("div", { key }, /* @__PURE__ */ import_react.default.createElement("dt", null, label), /* @__PURE__ */ import_react.default.createElement("dd", { "data-summary": key }, LABELS[configuration[key]]))));
  }
  function AccessoryPhoto({ accessory }) {
    return /* @__PURE__ */ import_react.default.createElement("div", { className: `accessory-photo ${accessory}` }, /* @__PURE__ */ import_react.default.createElement("img", { src: assetUrl(`assets/velori/chalk-${accessory}.png`), alt: accessory === "bag" ? "Velori in its padded carry bag" : "Velori on its charging dock" }));
  }

  // .design-sync/host-entry.mjs
  var script = typeof document !== "undefined" ? document.currentScript : null;
  if (script && script.src) define_import_meta_env_default.BASE_URL = new URL("./", script.src).href;
  return __toCommonJS(host_entry_exports);
})();
window.Velori=Velori.__dsMainNs?Object.assign({},Velori,Velori.__dsMainNs,{__dsMainNs:undefined}):Velori;
