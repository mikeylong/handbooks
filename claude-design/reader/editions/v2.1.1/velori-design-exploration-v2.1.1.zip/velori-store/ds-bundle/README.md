# Velori conventions

Velori is a small configurator kit for a personal-robot store. Every export lives on `window.Velori`. There is no provider or theme wrapper. Styling comes entirely from `styles.css`, which imports `_ds_bundle.css`. That file holds the `:root` tokens and every component class.

## Setup
- Load `styles.css` once and render components directly. Nothing needs a context wrapper.
- `styles.css` sets `body` to `var(--velori-color-canvas)` with `var(--velori-font-body)`. Don't override the body font.
- `FinishChoice`, `FaceChoice`, `AccessoryChoice` and `ExpressionSelect` are controlled. Always pass `value` and `onChange`, and keep the state in your own `useState`.
- Valid values: shell `chalk | pebble | graphite`, face `friendly | simple`, color `white | mint | blue | amber`, accessory `dock | bag | none`. Any other value renders an empty label.
- `SelectionMark` is absolutely positioned (top 8px, right 8px). Only place it inside a `position: relative` tile.
- `ProductPreview` and `AccessoryPhoto` load the original product photos from `assets/velori/` next to `_ds_bundle.js` (the bundle sets its asset base from its own script URL). `ProductPreview` renders any valid `configuration`; pass `unavailable` only to show its placeholder state on purpose. `AccessoryPhoto` takes `accessory="dock" | "bag"` and is a tall detail crop meant for a ~544px column.

## Styling idiom: CSS custom properties plus the kit's own classes
Use tokens for anything you build yourself. Never hard-code the hex values.
- Color: `--velori-color-ink`, `--velori-color-text`, `--velori-color-secondary`, `--velori-color-subtle`, `--velori-color-border`, `--velori-color-canvas`, `--velori-color-soft`, `--velori-color-selectedFill`, `--velori-color-selectedBorder`, `--velori-color-hover`, `--velori-color-white`
- Expression colors: `--velori-expression-white | -mint | -blue | -amber`
- Shape and size: `--velori-control-radius` (12px), `--velori-menu-radius` (16px), `--velori-primary-height` (48px), `--velori-select-height` (40px), `--velori-option-gap` (24px)
- Type: `--velori-font-body` (Arial stack) for UI, `--velori-font-display` (Georgia stack) for product headlines only

Page-layout classes that already exist: `store` (1024px framed page), `configuration-layout` (544px product column + options column), `product-panel`, `options`, `eyebrow` (10px tracked caps label), `sub` (secondary subhead), `row-label` (label row above a choice group), `description`, `product-title`, `caption`, `summary`. An `h1` inside `.options` gets the 32px page heading style.

## Where the truth lives
- `_ds_bundle.css` has every token and class above. Read it before styling.
- `components/general/<Name>/<Name>.d.ts` is each component's props. `<Name>.prompt.md` has its usage.

## Example
```jsx
const { StoreHeader, FinishChoice, ExpressionSelect, PrimaryButton } = window.Velori;
function Configure() {
  const [shell, setShell] = React.useState('chalk');
  const [color, setColor] = React.useState('white');
  return (
    <main className="store">
      <StoreHeader />
      <section className="options">
        <p className="eyebrow">THE DETAILS MAKE IT YOURS</p>
        <h1>Make Velori yours.</h1>
        <p className="sub">A finish, a face, a little personality.</p>
        <div className="row-label"><span>Shell finish</span><span>{shell}</span></div>
        <FinishChoice value={shell} onChange={setShell} />
        <ExpressionSelect value={color} onChange={setColor} />
        <div style={{ marginTop: 24 }}><PrimaryButton>Continue</PrimaryButton></div>
      </section>
    </main>
  );
}
```

# Velori (velori-store-handbook-sample@0.1.0)

This design system is the published velori-store-handbook-sample React library, bundled as a single
browser global. All 13 components are the real upstream code.

## Where things are

- `_ds_bundle.js` — the whole-DS bundle at the project root; loads every component to `window.Velori`. First line is a `/* @ds-bundle: … */` metadata header.
- `styles.css` — the single stylesheet entry: it `@import`s the tokens, fonts, and component styles (`_ds_bundle.css`). Link this one file.
- `components/<group>/<Name>/<Name>.prompt.md` (example JSX + variants), `<Name>.d.ts` (types), `<Name>.html` (variant grid).
- `tokens/*.css` — CSS custom properties, names verbatim from upstream.
- `fonts/` — `@font-face` files + `fonts.css` (when the package ships fonts).
- `guidelines/` — the design system's own usage guidance (3 doc(s), see `guidelines/index.md`). Read these before composing larger layouts.

For a specific component, `read_file("components/<group>/<Name>/<Name>.prompt.md")`.

## Loading

Add these two lines to your page once (React must be on the page first):

```html
<link rel="stylesheet" href="styles.css">
<script src="_ds_bundle.js"></script>
```

Components are then available at `window.Velori.*`. Mount into a dedicated child node (e.g. `<div id="ds-root">`), not the host page's own React root, so the two trees don't collide:

```jsx
const { AccessoryChoice } = window.Velori;
ReactDOM.createRoot(document.getElementById('ds-root')).render(<AccessoryChoice />);
```

## Tokens

27 CSS custom properties from velori-store-handbook-sample. Names are
preserved verbatim from upstream. They are declared inside `_ds_bundle.css` (this DS ships one compiled stylesheet rather than separate token files).

- **color** (12): `--velori-color-ink`, `--velori-color-text`, `--velori-color-secondary`, …
- **spacing** (3): `--velori-option-gap`, `--velori-menu-padding`, `--velori-menu-gap`
- **typography** (2): `--velori-font-body`, `--velori-font-display`
- **radius** (2): `--velori-control-radius`, `--velori-menu-radius`
- **other** (8): `--velori-expression-white`, `--velori-expression-mint`, `--velori-expression-blue`, …

## Components

### general
- `AccessoryChoice`
- `AccessoryPhoto`
- `Brand`
- `ChoiceGroup`
- `ConfigurationSummary`
- `ExpressionSelect`
- `FaceChoice`
- `FinishChoice`
- `PrimaryButton`
- `ProductPreview`
- `SelectionMark`
- `StoreHeader`
- `VeloriIcon`
