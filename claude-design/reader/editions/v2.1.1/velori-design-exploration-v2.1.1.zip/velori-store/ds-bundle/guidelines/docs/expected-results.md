# Check the result

1. An extracted copy installs, builds, and runs with its own assets. CLEAR is not required.
2. All 72 combinations show the correct finish, face, expression color, accessory, and caption. Rapid changes cannot leave an old image under new labels.
3. Continue is Ink/white, 48px high, with 12px corners. Accessory cards have 24px gaps. Purple Continue and 8px gaps appear only in named fixtures.
4. Details navigation returns to the same configuration. Browsing Charging dock does not replace a selected Carry bag.
5. Review shows the chosen robot and all four values. Edit and Back keep those values. Focus reaches the new heading, then returns to Continue or the accessory-details control when you go back.
6. The keyboard can operate choices and the dropdown, including cancellation and typeahead. Narrow layout has no horizontal overflow.
7. Reload retains choices when storage is available. Reset changes only the sample namespace. Blocked storage keeps the current visit usable.
8. Missing product imagery does not erase configuration values. A real image failure offers a retry.
9. Figma uses linked native component instances and shared variables. Actual prototype captions, images, selected states, summaries, and return paths agree.
10. Claude Design returns the intended organization and system, a successful import, a generated interactive result, and the actual exported handoff. Record each separately from local checks.
11. The implemented change can be traced to the exported result. Asset redistribution terms are established before a public download is prepared. Publication requires its own release action.
