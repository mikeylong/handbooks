# Guidelines

- [product-brief](./docs/product-brief.md)
- [inventory](./docs/inventory.md)
- [expected-results](./docs/expected-results.md)
