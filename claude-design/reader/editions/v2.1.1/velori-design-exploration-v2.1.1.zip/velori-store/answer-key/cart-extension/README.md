# Locally authored cart extension

These are the selected runtime source resources used to extend the October 6 offline Claude Design export. Open the parent `velori-review-prototype.html` for the self-contained runnable result. The JSX and HTML template here are source records; their resource UUIDs are resolved by the standalone export loader.

The cart is a single-item teaching prototype. Add to cart snapshots all four selected choices, sets quantity one and opens Cart. A repeated addition replaces the same item. Edit cart item restores its snapshot. Session storage preserves it across a same-tab reload. Fixture reset clears it. The staged unavailable accessory must be changed before adding. There is no payment or order submission.

This extension is local work. The retained native Claude Design trial and Figma continuation describe the preceding Review direction.
