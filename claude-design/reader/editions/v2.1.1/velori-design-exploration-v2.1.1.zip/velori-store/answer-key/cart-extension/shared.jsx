const SR = window.DesignSystem_1123a3;
const { VeloriBrand: SrBrand, VeloriProductPreview: SrPreview, VeloriFinishChoice: SrFinish, VeloriFaceChoice: SrFace, VeloriAccessoryChoice: SrAcc, VeloriColorSelect: SrSelect, VeloriPrimaryButton: SrButton, VeloriSelectionMark: SrMark } = SR;

const SR_FIXTURE = { finish: "graphite", face: "simple", color: "amber", accessory: "carry bag" };
const SR_FIXTURES = {
  default: { label: "Default · Graphite, Simple, Amber, Carry bag", cfg: SR_FIXTURE, unavailable: [], imageError: false },
  "no-accessory": { label: "No accessory · Accessory None", cfg: { ...SR_FIXTURE, accessory: "none" }, unavailable: [], imageError: false },
  unavailable: { label: "Staged · Carry bag unavailable", cfg: SR_FIXTURE, unavailable: ["carry bag"], imageError: false },
  "image-error": { label: "Image error · first load simulated", cfg: SR_FIXTURE, unavailable: [], imageError: true },
};
const SR_NAMES = {
  finish: { chalk: "Chalk", pebble: "Pebble", graphite: "Graphite" },
  face: { friendly: "Friendly", simple: "Simple" },
  color: { white: "White", mint: "Mint", blue: "Blue", amber: "Amber" },
  accessory: { dock: "Dock", "carry bag": "Carry bag", none: "None" },
};
const SR_SWATCH = { white: "#F4F6F2", mint: "#78EBC8", blue: "#80C8FF", amber: "#FFCC70", chalk: "var(--color-chalk)", pebble: "var(--color-pebble)", graphite: "var(--color-graphite)" };
const SR_ACC_COPY = {
  dock: "A charging dock gives your robot a place to rest.",
  "carry bag": "A padded carry bag keeps Velori protected on the move.",
  none: "Just Velori, ready to make itself at home.",
};
const SR_ACC_INFO = { dock: { title: "Charging dock", short: "Dock", hash: "#/accessory/dock" }, "carry bag": { title: "Carry bag", short: "Carry bag", hash: "#/accessory/carry-bag" } };
const SR_ROWS = [
  { k: "finish", label: "Shell finish", dot: true },
  { k: "face", label: "Face display" },
  { k: "color", label: "Expression color", dot: true },
  { k: "accessory", label: "Accessory" },
];
const srCaption = (c) => `${SR_NAMES.finish[c.finish]} shell · ${SR_NAMES.face[c.face]} face · ${SR_NAMES.color[c.color]} · ${SR_NAMES.accessory[c.accessory]}`;

const srT = {
  eyebrow: { font: "var(--text-eyebrow)", letterSpacing: "var(--type-eyebrow-tracking)", color: "var(--color-secondary)" },
  heading: { font: "var(--text-heading)", letterSpacing: "var(--type-heading-tracking)", color: "var(--color-text)", margin: 0 },
  body: { font: "var(--text-body)", color: "var(--color-secondary)", margin: 0 },
  label: { font: "var(--text-label)", color: "var(--color-text)", margin: 0 },
  caption: { font: "var(--text-caption)", color: "var(--color-secondary)", margin: 0 },
  title: { font: "var(--text-title)", color: "var(--color-text)" },
};

function useSrWidth() {
  const [w, setW] = React.useState(document.documentElement.clientWidth);
  React.useEffect(() => { const f = () => setW(document.documentElement.clientWidth); window.addEventListener("resize", f); return () => window.removeEventListener("resize", f); }, []);
  return w;
}
const srProductSize = (w, narrow) => narrow ? Math.max(200, Math.min(240, w - 72)) : Math.max(240, Math.min(360, w - 592));
const srMain = (narrow, desktopAreas, narrowAreas) => ({
  boxSizing: "border-box", width: "100%", maxWidth: 1024, margin: "0 auto", padding: narrow ? "20px 20px 40px" : "40px 40px 48px",
  display: "grid", gap: narrow ? 20 : "16px 48px", alignContent: "start",
  gridTemplateColumns: narrow ? "minmax(0,1fr)" : "minmax(0,1fr) minmax(0,400px)",
  gridTemplateAreas: narrow ? narrowAreas : desktopAreas,
  gridTemplateRows: narrow ? undefined : "auto auto 1fr",
});
const srPanel = (narrow) => ({ gridArea: "product", alignSelf: "start", boxSizing: "border-box", borderRadius: 12, background: "var(--color-soft)", boxShadow: "inset 0 0 0 1px var(--color-border)", padding: narrow ? "8px 16px 12px" : "24px 32px", display: "flex", flexDirection: "column", alignItems: "center", gap: 12, minWidth: 0 });

function SrStep({ n, label, state, onClick, hideLabel }) {
  const active = state === "active", done = state === "done";
  const inner = (
    <span style={{ display: "flex", gap: 8, alignItems: "center" }}>
      <span aria-hidden="true" style={{ width: 24, height: 24, borderRadius: 12, boxSizing: "border-box", display: "flex", alignItems: "center", justifyContent: "center", background: active ? "var(--color-ink)" : "var(--color-canvas)", boxShadow: `inset 0 0 0 1px ${active || done ? "var(--color-ink)" : "var(--color-border)"}`, font: "400 12px/1 var(--font-sans)", color: active ? "var(--color-onselectionmark)" : done ? "var(--color-text)" : "var(--color-subtle)" }}>{n}</span>
      <span className={hideLabel ? "sr-only" : undefined} style={{ font: active ? "700 13px/1 var(--font-sans)" : "400 12px/1 var(--font-sans)", color: active || done ? "var(--color-text)" : "var(--color-subtle)", whiteSpace: "nowrap" }}>{label}<span className="sr-only">{done ? ", completed" : active ? ", current step" : ""}</span></span>
    </span>
  );
  return onClick ? <button type="button" onClick={onClick} style={{ all: "unset", cursor: "pointer", borderRadius: 4 }}>{inner}</button> : inner;
}

function SrHeader({ step, onConfigure, narrow, tiny }) {
  return (
    <header style={{ minHeight: narrow ? 64 : 80, flexShrink: 0, boxSizing: "border-box", background: "var(--color-canvas)", borderBottom: "1px solid var(--color-border)", padding: narrow ? "12px 20px" : "0 40px", display: "flex", flexWrap: "wrap", justifyContent: "space-between", alignItems: "center", gap: "12px 16px" }}>
      <div style={{ minWidth: 0, maxWidth: "100%", overflow: "hidden" }}><SrBrand /></div>
      <nav aria-label="Configuration steps" style={{ minWidth: 0 }}>
        <ol style={{ listStyle: "none", margin: 0, padding: 0, display: "flex", gap: narrow ? 16 : 28 }}>
          <li aria-current={step === 1 ? "step" : undefined}><SrStep n="1" label="Configure" state={step === 1 ? "active" : "done"} onClick={step > 1 ? onConfigure : null} hideLabel={tiny && step !== 1} /></li>
          <li aria-current={step === 2 ? "step" : undefined}><SrStep n="2" label="Review" state={step === 2 ? "active" : step > 2 ? "done" : "upcoming"} hideLabel={tiny && step !== 2} /></li>
          <li aria-current={step === 3 ? "step" : undefined}><SrStep n="3" label="Cart" state={step === 3 ? "active" : "upcoming"} hideLabel={tiny && step !== 3} /></li>
        </ol>
      </nav>
    </header>
  );
}

function SrDot({ k }) {
  return <span aria-hidden="true" style={{ width: 12, height: 12, borderRadius: 6, flexShrink: 0, background: SR_SWATCH[k], boxShadow: "inset 0 0 0 1px var(--color-border)" }}></span>;
}

function SrPrimary({ label, onClick, type = "button", describedBy, btnRef }) {
  const [f, setF] = React.useState(false);
  return (
    <button ref={btnRef} type={type} className="sr-dsfocus" onClick={onClick} aria-describedby={describedBy}
      onFocus={(e) => setF(e.target.matches(":focus-visible"))} onBlur={() => setF(false)}
      style={{ all: "unset", cursor: "pointer", display: "block", width: "100%", maxWidth: 400, borderRadius: 12 }}>
      <SrButton label={label} state={f ? "focus" : "default"} style={{ width: "100%" }} />
    </button>
  );
}

function SrSecondary({ label, onClick, small, ariaDisabled, btnRef }) {
  return (
    <button ref={btnRef} type="button" className="sr-sec" aria-disabled={ariaDisabled || undefined} onClick={ariaDisabled ? undefined : onClick}
      style={{ all: "unset", cursor: ariaDisabled ? "default" : "pointer", boxSizing: "border-box", width: small ? "auto" : "100%", maxWidth: 400, height: small ? 40 : 48, padding: small ? "0 16px" : 0, borderRadius: 12, display: "flex", alignItems: "center", justifyContent: "center", background: "var(--color-surface)", boxShadow: "inset 0 0 0 1px var(--color-ink)", font: `700 ${small ? 13 : 14}px/20px var(--font-sans)`, color: "var(--color-text)", opacity: ariaDisabled ? 0.6 : 1, whiteSpace: "nowrap" }}>{label}</button>
  );
}

function SrLink({ children, onClick }) {
  return <button type="button" onClick={onClick} style={{ all: "unset", cursor: "pointer", borderRadius: 4, font: "700 13px/20px var(--font-sans)", color: "var(--color-text)", textDecoration: "underline", textDecorationColor: "var(--color-border)", textUnderlineOffset: 3 }}>{children}</button>;
}

Object.assign(window, { SrMark, SrFinish, SrFace, SrAcc, SrSelect, SrPreview, SR_FIXTURE, SR_FIXTURES, SR_NAMES, SR_SWATCH, SR_ACC_COPY, SR_ACC_INFO, SR_ROWS, srCaption, srT, useSrWidth, srProductSize, srMain, srPanel, SrHeader, SrDot, SrPrimary, SrSecondary, SrLink });
