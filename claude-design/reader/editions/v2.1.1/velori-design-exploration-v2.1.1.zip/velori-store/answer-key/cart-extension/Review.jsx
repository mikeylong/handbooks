function SrSummary({ cfg, blocked }) {
  return (
    <dl style={{ margin: 0, borderTop: "1px solid var(--color-border)" }}>
      {SR_ROWS.map((r) => (
        <div key={r.k} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 16, minHeight: 52, borderBottom: "1px solid var(--color-border)" }}>
          <dt style={{ font: "400 13px/20px var(--font-sans)", color: "var(--color-secondary)" }}>{r.label}</dt>
          <dd style={{ margin: 0, display: "flex", alignItems: "center", flexWrap: "wrap", justifyContent: "flex-end", gap: 8, font: "700 15px/20px var(--font-sans)", color: "var(--color-text)" }}>
            {r.dot && <SrDot k={cfg[r.k]} />}{SR_NAMES[r.k][cfg[r.k]]}
            {r.k === "accessory" && blocked && <span style={{ font: "400 12px/16px var(--font-sans)", color: "var(--color-text)", padding: "2px 8px", borderRadius: 999, boxShadow: "inset 0 0 0 1px var(--color-ink)" }}>Unavailable</span>}
          </dd>
        </div>
      ))}
    </dl>
  );
}

function SrReview({ cfg, set, w, narrow, onEdit, onConfirm, unavailable, img, headingRef, announce }) {
  const size = srProductSize(w, narrow);
  const blocked = unavailable.includes(cfg.accessory);
  const confirmRef = React.useRef(null);
  const wasBlocked = React.useRef(blocked);
  React.useEffect(() => {
    if (wasBlocked.current && !blocked && confirmRef.current) confirmRef.current.focus();
    wasBlocked.current = blocked;
  }, [blocked]);
  const choose = (acc) => { set({ accessory: acc }); announce(`Accessory changed to ${SR_NAMES.accessory[acc]}. Your other choices are kept.`); };
  return (
    <main data-screen-label="Review" style={srMain(narrow, '"product intro" "product summary" "details summary"', '"intro" "product" "summary" "details"')}>
      <div style={{ gridArea: "intro", display: "flex", flexDirection: "column", gap: 6 }}>
        <span style={srT.eyebrow}>BEFORE YOU ADD TO CART</span>
        <h1 ref={headingRef} tabIndex={-1} style={srT.heading}>Check your configuration</h1>
        <p style={srT.body}>Review each choice. Use Edit configuration to make changes.</p>
      </div>
      <div style={srPanel(narrow)}><SrProductFrame cfg={cfg} size={size} img={img} /></div>
      <section aria-label="Your choices" style={{ gridArea: "summary", display: "flex", flexDirection: "column", gap: 20, minWidth: 0 }}>
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          <SrSummary cfg={cfg} blocked={blocked} />
          {cfg.accessory === "none" && <p style={srT.caption}>No accessory added. You can add one in Edit configuration.</p>}
        </div>
        {
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            {blocked && (
              <div role="alert" style={{ display: "flex", flexDirection: "column", gap: 8, padding: 16, borderRadius: 12, background: "var(--color-surface)", boxShadow: "inset 0 0 0 2px var(--color-ink)", maxWidth: 400, boxSizing: "border-box" }}>
                <h2 style={srT.label}>Carry bag is unavailable</h2>
                <p style={srT.caption}>It can't be included in this configuration right now. Choose Dock or None to continue. Your other three choices stay as they are.</p>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 12, marginTop: 4 }}>
                  <SrSecondary small label="Choose Dock" onClick={() => choose("dock")} />
                  <SrSecondary small label="Choose None" onClick={() => choose("none")} />
                </div>
              </div>
            )}
            <SrSecondary label="Edit configuration" onClick={onEdit} />
            {!blocked && <SrPrimary btnRef={confirmRef} label="Add to cart" onClick={onConfirm} describedBy="sr-confirm-note" />}
            <p id="sr-confirm-note" style={{ ...srT.caption, maxWidth: 400 }}>Add this configured robot to your cart. No payment is taken.</p>
          </div>
        }
      </section>
      <div style={{ gridArea: "details", display: "flex", flexDirection: "column", gap: 6 }}>
        <span style={srT.title}>Velori, made for your home.</span>
        <span style={srT.caption}>{SR_ACC_COPY[cfg.accessory]}</span>
      </div>
    </main>
  );
}
function SrCart({ item, w, narrow, img, headingRef, onEdit }) {
  return (
    <main data-screen-label="Cart" style={srMain(narrow, '"product intro" "product summary" "details summary"', '"intro" "product" "summary" "details"')}>
      <div style={{ gridArea: "intro", display: "flex", flexDirection: "column", gap: 6 }}>
        <span style={srT.eyebrow}>YOUR CART</span>
        <h1 ref={headingRef} tabIndex={-1} style={srT.heading}>{item ? "Added to your cart" : "Your cart is empty"}</h1>
        <p style={srT.body}>{item ? "Your configured Velori is saved below. No order has been placed." : "Configure a Velori, then review your choices and add it to your cart."}</p>
      </div>
      {item && <div style={srPanel(narrow)}><SrProductFrame cfg={item} size={srProductSize(w, narrow)} img={img} /></div>}
      <section aria-label="Cart item" style={{ gridArea: "summary", display: "flex", flexDirection: "column", gap: 20, minWidth: 0 }}>
        {item && <React.Fragment><h2 style={srT.title}>Velori personal robot</h2><SrSummary cfg={item} blocked={false} /><p style={srT.label}>Quantity: 1</p></React.Fragment>}
        <SrSecondary label={item ? "Edit cart item" : "Configure Velori"} onClick={onEdit} />
        {item && <p style={srT.caption}>Changes update this cart item after you review and add it again.</p>}
      </section>
      {item && <div style={{ gridArea: "details" }}><p style={srT.caption}>{SR_ACC_COPY[item.accessory]}</p></div>}
    </main>
  );
}
Object.assign(window, { SrReview, SrCart });
