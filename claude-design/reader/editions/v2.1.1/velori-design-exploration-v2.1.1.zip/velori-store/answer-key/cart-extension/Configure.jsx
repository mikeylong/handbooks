function SrConfigure({ cfg, set, w, narrow, mode, onPrimary, onDetails, unavailable, img, headingRef }) {
  const edit = mode === "edit";
  const size = srProductSize(w, narrow);
  const accUnavailable = unavailable.includes(cfg.accessory);
  const tileGap = narrow ? 12 : 24;
  return (
    <main data-screen-label={edit ? "Edit configuration" : "Configure"} style={srMain(narrow, '"product intro" "product fields" "product fields"', '"intro" "product" "fields"')}>
      <div style={{ gridArea: "intro", display: "flex", flexDirection: "column", gap: 6 }}>
        <span style={srT.eyebrow}>{edit ? "EDIT YOUR CHOICES" : "THE DETAILS MAKE IT YOURS"}</span>
        <h1 ref={headingRef} tabIndex={-1} style={srT.heading}>{edit ? "Edit configuration" : "Make Velori yours."}</h1>
        <p style={srT.body}>{edit ? "Your current choices are kept. Change any of them." : "A finish, a face, a little personality."}</p>
      </div>
      <div style={{ ...srPanel(narrow), position: narrow ? "static" : "sticky", top: 24 }}>
        <SrProductFrame cfg={cfg} size={size} img={img} />
        <span style={{ ...srT.caption, textAlign: "center" }}>{srCaption(cfg)}</span>
      </div>
      <form onSubmit={(e) => { e.preventDefault(); onPrimary(); }} style={{ gridArea: "fields", display: "flex", flexDirection: "column", gap: 20, minWidth: 0 }}>
        <SrRadioGroup name="finish" legend="Shell finish" valueText={SR_NAMES.finish[cfg.finish]} values={["chalk", "pebble", "graphite"]} value={cfg.finish} Comp={SrFinish} onPick={(v) => set({ finish: v })} tileWidth={117.333} gap={tileGap} />
        <SrRadioGroup name="face" legend="Face display" valueText={SR_NAMES.face[cfg.face]} values={["friendly", "simple"]} value={cfg.face} Comp={SrFace} onPick={(v) => set({ face: v })} tileWidth={194} gap={12} />
        <SrColorField value={cfg.color} onPick={(v) => set({ color: v })} />
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          <SrRadioGroup name="accessory" legend="Accessories" valueText={SR_NAMES.accessory[cfg.accessory]} values={["dock", "carry bag", "none"]} value={cfg.accessory} Comp={SrAcc} onPick={(v) => set({ accessory: v })} tileWidth={117.333} gap={tileGap} disabled={unavailable} describedBy="sr-acc-note" />
          <p id="sr-acc-note" style={{ ...srT.caption, color: accUnavailable ? "var(--color-text)" : "var(--color-secondary)" }}>
            {accUnavailable ? "Carry bag is currently unavailable. Choose Dock or None." : SR_ACC_COPY[cfg.accessory]}
          </p>
          <div style={{ display: "flex", flexWrap: "wrap", gap: "4px 20px" }}>
            <SrLink onClick={() => onDetails("dock")}>Charging dock details</SrLink>
            <SrLink onClick={() => onDetails("carry bag")}>Carry bag details</SrLink>
          </div>
        </div>
        <SrPrimary type="submit" label="Continue" />
      </form>
    </main>
  );
}
Object.assign(window, { SrConfigure });
