import {createServer} from 'node:http';
import {readFile,readdir} from 'node:fs/promises';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {join,extname,dirname} from 'node:path';
const packageRoot=join(dirname(fileURLToPath(import.meta.url)),'..');
const packet=join(packageRoot,'handoff/2026-10-04');
const mount='/_ds/velori-27899fe3-9fec-45c7-b3fb-d2c855483278/';
const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript','.css':'text/css','.png':'image/png','.svg':'image/svg+xml'};
export async function startHandoff(port=4201){
 const files=new Map([['/Velori Store.dc.html',join(packet,'Velori Store.dc.html')],['/support.js',join(packet,'support.js')],['/vendor/react.js',join(packet,'vendor/react.js')],['/vendor/react-dom.js',join(packet,'vendor/react-dom.js')]]);
 for(const name of ['_ds_bundle.js','_ds_bundle.css','styles.css'])files.set(mount+name,join(packet,mount,name));
 for(const name of await readdir(join(packageRoot,'public/assets/velori')))files.set(mount+'assets/velori/'+name,join(packageRoot,'public/assets/velori',name));
 const native=await readFile(join(packet,'Velori Store.dc.html'),'utf8');
 const needle='<script src="./support.js"></script>';
 if(!native.includes(needle))throw Error('Native bootstrap contract changed');
 const entry=native.replace(needle,'<script src="./vendor/react.js"></script>\n<script src="./vendor/react-dom.js"></script>\n'+needle);
 const server=createServer(async(req,res)=>{
  try{
   const path=decodeURIComponent(new URL(req.url,'http://127.0.0.1').pathname);
   if(path==='/'||path==='/index.html'){res.setHeader('Content-Type',mime['.html']);res.end(entry);return;}
   const file=files.get(path);
   if(!file){res.statusCode=404;res.end('Not found');return;}
   res.setHeader('Content-Type',mime[extname(file)]||'application/octet-stream');res.end(await readFile(file));
  }catch{res.statusCode=400;res.end('Invalid request');}
 });
 await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(port,'127.0.0.1',resolve);});
 return {server,url:`http://127.0.0.1:${server.address().port}/`};
}
if(import.meta.url===pathToFileURL(process.argv[1]).href){const {url}=await startHandoff(Number(process.argv[2]||4201));console.log(`Native Velori Code handoff: ${url}`);}
