// Validate the saved native Code handoff through its documented localhost adapter.
// React copies from the native export load locally; external HTTPS requests are blocked.
import {chromium} from 'playwright';
import {startHandoff} from './serve-native-handoff.mjs';
import { writeFile, mkdir } from 'node:fs/promises'; import { join, dirname } from 'node:path'; import { fileURLToPath } from 'node:url';
const here=process.env.VELORI_HANDOFF_OUTPUT||join(dirname(fileURLToPath(import.meta.url)),'../validation/native-handoff');
await mkdir(here,{recursive:true});
const {server:srv,url:base}=await startHandoff(0);
const served=[];
const results = []; const ok = (name, pass, detail) => { results.push({ name, pass: !!pass, detail }); console.log(pass ? 'PASS' : 'FAIL', name, detail ? JSON.stringify(detail).slice(0, 220) : ''); };
const browser=await chromium.launch(process.env.VELORI_CHROMIUM_EXECUTABLE?{executablePath:process.env.VELORI_CHROMIUM_EXECUTABLE}:{});
const ctx = await browser.newContext({ viewport: { width: 1100, height: 900 } });
await ctx.route('https://**',rt=>rt.abort());
const pg = await ctx.newPage(); const errs = []; pg.on('pageerror', e => errs.push(e.message)); pg.on('console', m => { if (m.type() === 'error') errs.push('console: ' + m.text()); });
const bad = []; pg.on('response', x => { if (x.status() >= 400) bad.push(x.status() + ' ' + x.url()); });
const LABELS = { chalk:'Chalk', pebble:'Pebble', graphite:'Graphite', friendly:'Friendly', simple:'Simple', white:'White', mint:'Mint', blue:'Blue', amber:'Amber', dock:'Dock', bag:'Carry bag', none:'None' };
const ready = async () => { await pg.waitForFunction(() => { const v = document.querySelector('[data-image-state]'); return v && v.dataset.imageState !== 'loading'; }, null, { timeout: 15000 }); };
const imgsOk = () => pg.$$eval('.product-view img', a => a.length > 0 && a.every(i => i.complete && i.naturalWidth > 0));
await pg.goto(base); await pg.evaluate(() => { try { localStorage.clear(); } catch {} }); await pg.goto(base + '#configure'); await pg.reload();
await pg.waitForSelector('h1#configure-heading', { timeout: 20000 }); await ready();
ok('boot: window.Velori from _ds_bundle.js, configure screen', await pg.evaluate(() => !!window.Velori && Object.keys(window.Velori).length === 13), { exports: await pg.evaluate(() => Object.keys(window.Velori || {}).length) });
ok('defaults Chalk/Friendly/White/Dock, photo ready', (await pg.textContent('.caption')).trim() === 'Chalk shell · Friendly face · White · Dock' && await imgsOk());

// 72 configurations through the real controls
const selectColor = async c => { await pg.click('.select-trigger'); await pg.click(`[role=option]:has-text("${LABELS[c]}")`); };
let pass72 = 0; const fail72 = [];
for (const shell of ['chalk','pebble','graphite']) for (const face of ['friendly','simple']) for (const color of ['white','mint','blue','amber']) for (const acc of ['dock','bag','none']) {
  await pg.click(`[data-choice="shell:${shell}"]`); await pg.click(`[data-choice="face:${face}"]`); await selectColor(color); await pg.click(`[data-choice="accessory:${acc}"]`);
  const want = `${LABELS[shell]} shell · ${LABELS[face]} face · ${LABELS[color]} · ${LABELS[acc]}`;
  await pg.waitForFunction(w => document.querySelector('.product-render')?.dataset.configuration === w && document.querySelector('[data-image-state]')?.dataset.imageState === 'ready', want, { timeout: 15000 }).catch(() => {});
  const st = await pg.evaluate(() => ({ cfg: document.querySelector('.product-render')?.dataset.configuration, state: document.querySelector('[data-image-state]')?.dataset.imageState, caption: document.querySelector('.caption')?.textContent.trim(), srcs: [...document.querySelectorAll('.product-view img')].map(i => new URL(i.src).pathname.split('/').pop()), face: getComputedStyle(document.querySelector('.expression-layer')).backgroundColor }));
  const loaded = await imgsOk();
  const good = st.cfg === want && st.caption === want && st.state === 'ready' && loaded;
  good ? pass72++ : fail72.push({ want, ...st, loaded });
  if (shell === 'graphite' && face === 'simple' && color === 'mint' && acc === 'bag') await pg.screenshot({ path: join(here, 'config-graphite-simple-mint-bag.png') });
}
ok(`72 configurations: caption, render data-configuration, photo layers loaded`, pass72 === 72, { pass72, firstFailures: fail72.slice(0, 3) });

// Journey: configure -> review -> edit
await pg.click('[data-choice="shell:pebble"]'); await pg.click('[data-choice="face:simple"]'); await selectColor('amber'); await pg.click('[data-choice="accessory:bag"]'); await ready();
await pg.click('#continue-button'); await pg.waitForSelector('h1#review-heading');
await pg.waitForFunction(() => document.activeElement?.id === 'review-heading', null, { timeout: 3000 }).catch(() => {});
const summary = await pg.$$eval('[data-summary]', a => Object.fromEntries(a.map(d => [d.dataset.summary, d.textContent])));
ok('review: hash #review, summary shows the four choices, focus on heading', (await pg.evaluate(() => location.hash)) === '#review' && JSON.stringify(summary) === JSON.stringify({ shell: 'Pebble', face: 'Simple', color: 'Amber', accessory: 'Carry bag' }) && (await pg.evaluate(() => document.activeElement?.id)) === 'review-heading', { summary, focus: await pg.evaluate(() => document.activeElement?.id) });
await pg.waitForFunction(() => document.querySelector('[data-image-state]')?.dataset.imageState === 'ready' && [...document.querySelectorAll('.product-view img')].every(i => i.complete && i.naturalWidth > 0), null, { timeout: 15000 }).catch(() => {});
const rv = await pg.evaluate(() => ({ state: document.querySelector('[data-image-state]')?.dataset.imageState, cfg: document.querySelector('.product-render')?.dataset.configuration, imgs: [...document.querySelectorAll('.product-view img')].map(i => [new URL(i.src).pathname.split('/').pop(), i.complete && i.naturalWidth > 0]) }));
ok('review: photo ready for the chosen configuration', rv.state === 'ready' && rv.cfg === 'Pebble shell · Simple face · Amber · Carry bag' && rv.imgs.length > 0 && rv.imgs.every(x => x[1]), rv);
await pg.screenshot({ path: join(here, 'review.png') });
await pg.click('#edit-button'); await pg.waitForSelector('h1#configure-heading');
await pg.waitForFunction(() => document.activeElement?.id === 'continue-button', null, { timeout: 3000 }).catch(() => {});
ok('edit: back to configure with choices kept, focus on Continue', (await pg.textContent('.caption')).trim() === 'Pebble shell · Simple face · Amber · Carry bag' && (await pg.evaluate(() => document.activeElement?.id)) === 'continue-button', { focus: await pg.evaluate(() => document.activeElement?.id) });
await pg.click('#continue-button'); await pg.waitForSelector('h1#review-heading'); await pg.click('.review-back'); await pg.waitForSelector('h1#configure-heading');
ok('review "← Back" returns to configure with choices kept', (await pg.textContent('.caption')).trim() === 'Pebble shell · Simple face · Amber · Carry bag');

// Details: open, browse other accessory without changing the selection, back
await ready(); await pg.click('#accessory-details'); await pg.waitForSelector('h1#details-heading');
const d1 = { hash: await pg.evaluate(() => location.hash), title: await pg.textContent('#details-heading'), img: await pg.$eval('.accessory-photo img', i => i.complete && i.naturalWidth > 0 && new URL(i.src).pathname.split('/').pop()) };
ok('details: opens the selected accessory (Carry bag) with its photo', d1.hash === '#details-bag' && d1.title === 'Carry bag' && d1.img === 'chalk-bag.png', d1);
await pg.click('.detail-tabs button:has-text("Charging dock")'); await pg.waitForFunction(() => location.hash === '#details-dock');
await pg.waitForFunction(() => { const i = document.querySelector('.accessory-photo img'); return i && i.complete && i.naturalWidth > 0 && i.src.endsWith('chalk-dock.png'); }, null, { timeout: 8000 }).catch(() => {});
const d2 = { title: await pg.textContent('#details-heading'), sel: (await pg.textContent('.detail-facts dd:last-of-type')).trim(), img: await pg.$eval('.accessory-photo img', i => i.complete && i.naturalWidth > 0 && new URL(i.src).pathname.split('/').pop()) };
ok('details: browsing Charging dock does not change the selected accessory', d2.title === 'Charging dock' && d2.img === 'chalk-dock.png' && /Not selected\. Your accessory is Carry bag/.test(d2.sel), d2);
await pg.screenshot({ path: join(here, 'details-dock.png') });
await pg.click('.store-header .back-link'); await pg.waitForSelector('h1#configure-heading');
await pg.waitForFunction(() => document.activeElement?.id === 'accessory-details', null, { timeout: 3000 }).catch(() => {});
ok('details back: configure, accessory still Carry bag, focus on details control', (await pg.textContent('.caption')).trim().endsWith('· Carry bag') && (await pg.evaluate(() => document.activeElement?.id)) === 'accessory-details', { focus: await pg.evaluate(() => document.activeElement?.id) });

// Keyboard: choices and the dropdown (open, arrows, Enter, Escape cancel, typeahead)
await pg.focus('[data-choice="shell:graphite"]'); await pg.keyboard.press('Enter'); await pg.focus('[data-choice="face:friendly"]'); await pg.keyboard.press('Space');
await pg.focus('.select-trigger'); await pg.keyboard.press('ArrowDown'); const opened = await pg.getAttribute('.select-trigger', 'aria-expanded');
await pg.keyboard.press('Home'); await pg.keyboard.press('ArrowDown'); await pg.keyboard.press('Enter');
const afterEnter = (await pg.textContent('.caption')).trim();
await pg.keyboard.press('ArrowDown'); await pg.keyboard.press('End'); await pg.keyboard.press('Escape');
const afterEscape = { caption: (await pg.textContent('.caption')).trim(), expanded: await pg.getAttribute('.select-trigger', 'aria-expanded'), focus: await pg.evaluate(() => document.activeElement?.className) };
await pg.keyboard.type('b'); await pg.keyboard.press('Enter'); const afterType = (await pg.textContent('.caption')).trim();
ok('keyboard: Enter/Space choose tiles; dropdown opens, arrows+Enter commit, Escape cancels, typeahead works', opened === 'true' && afterEnter === 'Graphite shell · Friendly face · Mint · Carry bag' && afterEscape.caption === afterEnter && afterEscape.expanded === 'false' && afterType === 'Graphite shell · Friendly face · Blue · Carry bag', { opened, afterEnter, afterEscape, afterType });
await pg.focus('#continue-button'); await pg.keyboard.press('Enter'); await pg.waitForSelector('h1#review-heading', { timeout: 5000 }).catch(() => {});
ok('keyboard: Continue via Enter reaches review', (await pg.evaluate(() => location.hash)) === '#review');
await pg.goBack(); await pg.waitForSelector('h1#configure-heading');

// Reload persistence
await pg.reload(); await pg.waitForSelector('h1#configure-heading'); await ready();
ok('reload keeps choices (localStorage velori.store.handbook-exercise.v1)', (await pg.textContent('.caption')).trim() === 'Graphite shell · Friendly face · Blue · Carry bag', { stored: await pg.evaluate(() => localStorage.getItem('velori.store.handbook-exercise.v1')) });

// Image failure: real failed load -> placeholder + Retry, choices kept, retry recovers; and the simulate toggle
await pg.click('[data-choice="face:simple"]');
await pg.waitForFunction(() => document.querySelector('.caption')?.textContent.includes('Simple face') && document.querySelector('[data-image-state]')?.dataset.imageState === 'ready');
let abortedPhotos = 0;
await ctx.route('**/assets/velori/graphite-bag-shell-v2.png', rt => { abortedPhotos++; return rt.abort(); });
// Reload clears the component's decoded-image cache and exercises a genuine unavailable asset.
await pg.reload();
await pg.waitForFunction(() => document.querySelector('[data-image-state]')?.dataset.imageState === 'error', null, {timeout:15000});
const fail = { state: await pg.$eval('[data-image-state]', e => e.dataset.imageState), text: await pg.textContent('.image-placeholder'), retry: await pg.$('.image-placeholder button') !== null, caption: (await pg.textContent('.caption')).trim() };
ok('real image failure: unavailable message + Retry, choices kept', abortedPhotos > 0 && fail.state === 'error' && /Product image unavailable/.test(fail.text) && fail.retry && fail.caption === 'Graphite shell · Simple face · Blue · Carry bag', fail);
await pg.screenshot({ path: join(here, 'image-failure.png') });
await ctx.unroute('**/assets/velori/graphite-bag-shell-v2.png'); const retryReqs = []; const onReq = r => { if (r.url().includes('graphite-bag-shell-v2')) retryReqs.push(r.url()); }; pg.on('request', onReq); await pg.click('.image-placeholder button');
await pg.waitForFunction(() => document.querySelector('[data-image-state]')?.dataset.imageState === 'ready', null, { timeout: 15000 }).catch(() => {}); pg.off('request', onReq);
const rt = { state: await pg.$eval('[data-image-state]', e => e.dataset.imageState), imgs: await imgsOk(), retryRequests: retryReqs.length };
ok('Retry after failure loads the photo', rt.state === 'ready' && rt.imgs, rt);
await pg.click('.sample-tools button:has-text("Simulate unavailable image")');
const sim = { state: await pg.$eval('[data-image-state]', e => e.dataset.imageState), retry: await pg.$('.image-placeholder button') !== null };
await pg.click('.sample-tools button:has-text("Retry product image")'); await ready();
ok('simulate unavailable toggle: placeholder without Retry, then restores', sim.state === 'error' && !sim.retry && (await pg.$eval('[data-image-state]', e => e.dataset.imageState)) === 'ready', sim);

// Reset clears only the sample key
await pg.evaluate(() => localStorage.setItem('unrelated', 'keep')); await pg.click('.sample-tools button:has-text("Reset sample choices")');
ok('reset: defaults restored, only the sample key removed', (await pg.textContent('.caption')).trim() === 'Chalk shell · Friendly face · White · Dock' && await pg.evaluate(() => localStorage.getItem('velori.store.handbook-exercise.v1') === null && localStorage.getItem('unrelated') === 'keep'));

// Blocked storage keeps the visit usable
const pg2 = await ctx.newPage(); await pg2.addInitScript(() => { Object.defineProperty(window, 'localStorage', { get() { throw new Error('blocked'); } }); });
await pg2.goto(base); await pg2.waitForSelector('h1#configure-heading'); await pg2.click('[data-choice="shell:pebble"]');
ok('blocked storage: notice shown, choices still work', /Browser storage is unavailable/.test(await pg2.textContent('.sample-tools p')) && (await pg2.textContent('.caption')).trim().startsWith('Pebble shell'));
await pg2.close();

// Narrow layout overflow
await pg.setViewportSize({ width: 390, height: 844 }); await pg.waitForTimeout(300);
const ov = await pg.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth }));
ok('narrow 390px: no horizontal overflow', ov.sw <= ov.cw, ov);
await pg.screenshot({ path: join(here, 'narrow-390.png'), fullPage: true });

const unexpected = errs.filter(e => !/ERR_FAILED/.test(e)); ok('no page errors and no 4xx/5xx responses (the one ERR_FAILED is the deliberately aborted photo)', unexpected.length === 0 && bad.length === 0 && errs.length - unexpected.length <= 1, { errs, bad: bad.slice(0, 5) });
await browser.close(); srv.close();
const summaryOut = { ranAt: new Date().toISOString(), served:'portable native handoff entry with recorded host adaptations',reactSource:'native-export React UMD files loaded locally; all HTTPS requests blocked', passed: results.filter(r => r.pass).length, total: results.length, results, uniqueFilesServed: [...new Set(served)].sort() };
await writeFile(join(here, 'results.json'), JSON.stringify(summaryOut, null, 2) + '\n');
console.log(`\n${summaryOut.passed}/${summaryOut.total} checks passed`);
if(summaryOut.passed!==summaryOut.total)process.exitCode=1;
