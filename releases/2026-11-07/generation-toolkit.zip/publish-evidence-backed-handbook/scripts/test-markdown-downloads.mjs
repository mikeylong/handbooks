import assert from 'node:assert/strict';
import {mkdtemp,readFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {readerMarkdown,writeMarkdownEdition,markdownLink} from './markdown-downloads.mjs';
import {downloadLinks,installReaderDownloads,validateDownloads} from './pdf-downloads.mjs';
const edition={id:'future-book',title:'Future & book',version:'3.0.0',date:'2026-10-04'};
const code='  first\n\n\n  second ```\n';
const html=`<main id="main-content"><section class="cover"><h1>Future &amp; book</h1><p>Cover chrome</p></section><section class="contents-page"><h2>Contents</h2></section><section class="chapter" id="first"><h2>A &amp; B</h2><p>A named &rarr; rule with <strong>bold</strong>, <em>emphasis</em>, <code>x_y</code>, and a <a href="#second">return</a>.</p><pre><code class="language-js">${code}</code></pre><ol start="8"><li>Eight<ul><li>Nested</li></ul></li><li>Nine</li></ol><table><caption>Measured inputs</caption><tr><th>Meaning</th><th>Value</th></tr><tr><td>One | two</td><td><p>1</p><p>2</p></td></tr></table><figure class="reader-prompt"><figcaption><span class="reader-prompt-title">Code | Preserve</span></figcaption><div class="reader-prompt-body"><p>Keep &lt;value&gt; and &#96;&#96;&#96; exactly.</p><p>Second line.</p></div></figure><div class="semantic-diagram"><strong>Frame</strong><details><summary>Diagram relationships</summary><ul><li>Frame → Ground (feedback)</li></ul></details></div><div class="diagram-print">Duplicate raster label</div></section><section class="chapter" id="second"><h2>A &amp; B</h2><p>Second chapter.</p></section></main>`;
const {markdown,index}=readerMarkdown(html,edition);
assert.match(markdown,/title: "Future & book"/);
assert.match(markdown,/A named → rule/);
assert.match(markdown,/\[return\]\(#a--b-1\)/);
assert.ok(markdown.includes('````js\n'+code+'````'));
assert.match(markdown,/8\. Eight/);assert.match(markdown,/9\. Nine/);
assert.match(markdown,/Measured inputs/);assert.ok(markdown.includes('One \\| two'));
assert.ok(markdown.includes('````text\nKeep <value> and ``` exactly.\nSecond line.\n````'));
assert.equal(index.prompts,1);assert.equal(index.sections.length,2);
assert.match(markdown,/Frame → Ground \(feedback\)/);
assert.doesNotMatch(markdown,/Cover chrome|Duplicate raster label|## Contents/);
assert.throws(()=>readerMarkdown('<main id="main-content"></main>',edition),/no chapters/);
assert.throws(()=>readerMarkdown(html,{...edition,id:'../private'}),/identity/);
assert.throws(()=>readerMarkdown(html.replace('href="#second"','href="javascript:bad"'),edition),/Unsafe/);
assert.throws(()=>markdownLink(edition),/Missing/);
// A future title must get a complete edition without per-book download markup.
const future='<main id="main-content">'+Array.from({length:25},(_,i)=>`<section class="chapter"><h2>Chapter ${i+1}</h2><p>Known result ${i+1}.</p></section>`).join('')+'</main>';
assert.equal(readerMarkdown(future,edition).index.sections.length,25);
const root=await mkdtemp(join(tmpdir(),'handbook-markdown-'));
try{
 edition.markdown=await writeMarkdownEdition(root,edition,html);
 const file=await readFile(join(root,edition.markdown.publicUrl),'utf8');assert.equal(file,markdown);
 const variants=[{publicUrl:'/book.pdf',downloadFilename:'book.pdf',theme:'light',displayName:'Daytime version',pages:25,bytes:1000}];
 const links=downloadLinks(edition,variants);validateDownloads(links,edition,variants);
 assert.ok(links.indexOf('Markdown edition')<links.indexOf('Daytime version'));
 assert.match(links,/Plain text for tools and reuse/);
 assert.match(links,/25 pages, 1 KB/);
 const reader='<a href="book.pdf" download>PDF</a><main><a href="book.pdf" download>PDF</a></main>';
 assert.equal((installReaderDownloads(reader,edition,variants).match(/data-markdown-download/g)||[]).length,3);
 assert.throws(()=>validateDownloads(links.replace('data-markdown-download','removed'),edition,variants),/Missing Markdown/);
 assert.throws(()=>markdownLink({...edition,markdown:{...edition.markdown,version:'4.0.0'}}),/wrong/);
}finally{await rm(root,{recursive:true,force:true});}
console.log('Markdown content, code whitespace, prompts, lists, tables, links, diagrams, edition safety, required placement, and 25-chapter future edition passed.');

// Citation links stay within the Markdown edition and land at the full source.
const cited='<main id="main-content"><section class="chapter" id="intro"><h2>Introduction</h2><p>A claim <sup class="citation-marker"><a href="#ref-s9" aria-label="Citation S9">[S9]</a></sup>.</p><p class="reference-entry" id="ref-s9" tabindex="-1"><b>[S9] Source nine</b></p></section></main>';
const citations=readerMarkdown(cited,edition);
assert.ok(citations.markdown.includes('[[S9]](#s9-source-nine)') || citations.markdown.includes('[\\[S9\\]](#s9-source-nine)'));
assert.ok(citations.markdown.includes('#### **\\[S9\\] Source nine**'));
assert.ok(citations.index.sections.some(s=>s.anchor==='s9-source-nine'));
assert.ok(!citations.markdown.includes('https://handbooks.surfaces.systems/future-book/#ref-s9'));

// Publication is determined by the catalog, separately from artifact approval.
assert.match(readerMarkdown(html,{...edition,approvalStatus:'approved',publicationStatus:'published'}).markdown,/publication_status: "published"/);
assert.match(readerMarkdown(html,{...edition,approvalStatus:'approved'}).markdown,/publication_status: "candidate"/);
const worksheet='<main id="main-content"><section class="chapter"><h2>Worksheet</h2><table><caption>Extension brief</caption><tr><th>Field</th></tr><tr><td>Chosen robot</td></tr><tr><td>Accessories</td></tr></table></section></main>';
const single=readerMarkdown(worksheet,edition).markdown;
assert.ok(single.includes('| Field |\n| --- |\n| Chosen robot |\n| Accessories |'));

const screenshot='<main id="main-content"><section class="chapter"><h2>Screenshot chapter</h2><figure class="reader-screenshot" data-screenshot-figure="s01-start"><div class="reader-screenshot-panels"><div class="reader-screenshot-panel"><p class="reader-screenshot-label">Review</p><a href="/future-book/editions/v3.0.0/assets/screenshots/review-full.png"><img src="/future-book/editions/v3.0.0/assets/screenshots/review.png" alt="Graphite, Simple, Amber and Carry bag."></a><a class="reader-screenshot-larger" href="/future-book/editions/v3.0.0/assets/screenshots/review-full.png">View larger image</a></div></div><figcaption><strong>Figure 1.</strong> The four values agree.</figcaption></figure><figure class="chapter-art"><img src="assets/art.png" alt="Existing engraving"></figure></section></main>';
const screenshotExport=readerMarkdown(screenshot,edition);
assert.ok(screenshotExport.markdown.includes('![Graphite, Simple, Amber and Carry bag.](https://handbooks.surfaces.systems/future-book/editions/v3.0.0/assets/screenshots/review.png)'));
assert.ok(screenshotExport.markdown.includes('**Figure 1.** The four values agree.'));
assert.ok(screenshotExport.markdown.includes('[View larger image](https://handbooks.surfaces.systems/future-book/editions/v3.0.0/assets/screenshots/review-full.png)'));
assert.ok(screenshotExport.markdown.includes('Image description: Existing engraving'));
assert.equal(screenshotExport.index.figures.length,1);
assert.throws(()=>readerMarkdown(screenshot.replace('alt="Graphite, Simple, Amber and Carry bag."','alt=""'),edition),/Incomplete screenshot/);
assert.throws(()=>readerMarkdown(screenshot.replace('v3.0.0/assets/screenshots/review.png','v2.0.0/assets/screenshots/review.png'),edition),/immutable edition/);
assert.throws(()=>readerMarkdown(screenshot.replace('src="/future-book/editions/v3.0.0/assets/screenshots/review.png"','src="fi'+'le:///private/review.png"'),edition),/Unsafe/);
console.log('Screenshot alt text, captions, image links, immutable edition paths, and chapter-art fallback passed.');
const croppedScreenshot=screenshot.replace('data-screenshot-figure="s01-start"','data-screenshot-figure="s01-start" data-screenshot-distribution="internal-only"').replace('src="/future-book/editions/v3.0.0/assets/screenshots/review.png" alt="Graphite, Simple, Amber and Carry bag."','src="/future-book/editions/v3.0.0/assets/screenshots/review.png" width="1200" height="800" alt="Graphite, Simple, Amber and Carry bag."').replace('<img src="/future-book/editions/v3.0.0/assets/screenshots/review.png"','<span class="reader-screenshot-crop" data-screenshot-crop="300,100,600,400"><img src="/future-book/editions/v3.0.0/assets/screenshots/review.png"').replace('alt="Graphite, Simple, Amber and Carry bag."></a>','alt="Graphite, Simple, Amber and Carry bag."></span></a>').replaceAll('review-full.png','s01-start-panel-1.html');
const cropExport=readerMarkdown(croppedScreenshot,edition);
assert.ok(cropExport.markdown.includes('Source-pixel crop (x, y, width, height): 300, 100, 600, 400.'));
assert.ok(cropExport.markdown.includes('[View larger cropped image](https://handbooks.surfaces.systems/future-book/editions/v3.0.0/assets/screenshots/s01-start-panel-1.html)'));
assert.ok(!cropExport.markdown.includes('![Graphite'));
assert.deepEqual(cropExport.index.figures[0].images[0].crop,[300,100,600,400]);
assert.throws(()=>readerMarkdown(croppedScreenshot,{...edition,publicationStatus:'published'}),/Internal screenshot/);
assert.throws(()=>readerMarkdown(croppedScreenshot.replace('300,100,600,400','1000,100,600,400'),edition),/source bounds/);
assert.throws(()=>readerMarkdown(croppedScreenshot.replace('300,100,600,400','-1,100,600,400'),edition),/Invalid screenshot crop/);
console.log('Cropped screenshot descriptions, source bounds, matching larger views, and published-source privacy rejection passed.');
const concept=html.replace('<p>Second chapter.</p>','<figure class="reader-concept-diagram" data-diagram-title="Outcome loop" data-text-equivalent="The team delegates bounded work and reviews the evidence."><div aria-hidden="true">Drawing labels</div></figure>');
assert.ok(readerMarkdown(concept,edition).markdown.includes('**Outcome loop**\n\nThe team delegates bounded work and reviews the evidence.'));
assert.ok(!readerMarkdown(concept,edition).markdown.includes('Drawing labels'));
assert.throws(()=>readerMarkdown(concept.replace('data-text-equivalent="The team delegates bounded work and reviews the evidence."',''),edition),/text equivalent/);
console.log('Concept diagrams preserve their accessible text equivalent in Markdown.');
