#!/usr/bin/env python3
"""PDFKit raster regression and fresh-output gates; synthetic fixture, no release approval.

Requires macOS, a compiled render-pdfkit.swift, Poppler and the shared Python
runtime. Writes one synthetic PDF and preserves every command/output in a NEW
directory. Call the PDF skill authoring marker before running this test.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import os
import platform
import shutil
import subprocess
from pathlib import Path

from PIL import Image, ImageChops, ImageFilter, ImageStat
from pypdf import PdfReader, PdfWriter, Transformation
from pypdf.generic import RectangleObject
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen.canvas import Canvas
from reportlab.lib.colors import Color

TOOLKIT = Path(__file__).resolve().parents[1]


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path: Path, content: str) -> None:
    with path.open("x", encoding="utf-8") as handle:
        handle.write(content)


def fresh(path: Path) -> Path:
    path = path.expanduser().absolute()
    if ".." in path.parts or any(p.is_symlink() for p in (path, *path.parents)):
        raise ValueError("Output cannot traverse symlinks or parent references")
    if path.exists():
        raise ValueError("Output must not exist, even if empty")
    path.mkdir(parents=True)
    return path


def fixture(path: Path) -> None:
    fonts = TOOLKIT / "assets/design-system/fonts"
    for name, filename in (("ReviewSerif", "SourceSerif4-Regular.ttf"),
                           ("ReviewBold", "SourceSerif4-Bold.ttf"),
                           ("ReviewSans", "NotoSans-Regular.ttf"),
                           ("ReviewCode", "SourceCodePro-Regular.ttf")):
        pdfmetrics.registerFont(TTFont(name, str(fonts / filename)))
    memory = io.BytesIO()
    canvas = Canvas(memory, pagesize=(420, 594.96), invariant=True, pageCompression=1)
    for number in range(6):
        dark = number == 5
        canvas.setFillColorRGB(*((25 / 255, 25 / 255, 24 / 255) if dark else (1, 1, 1)))
        canvas.rect(0, 0, 420, 594.96, fill=1, stroke=0)
        canvas.setFillColorRGB(*((238 / 255, 236 / 255, 230 / 255) if dark else (0, 0, 0)))
        canvas.setFont("ReviewSerif", 24)
        canvas.drawString(36, 546, "PDFKit raster regression")
        for font, y in (("ReviewSerif", 505), ("ReviewBold", 480)):
            canvas.setFont(font, 10)
            canvas.drawString(36, y, "Regular and bold: minimum operational evidence.")
        canvas.setFont("ReviewSans", 7.2)
        for row in range(6):
            canvas.drawString(36, 430 - 17 * row, f"Table row {row + 1}: source / fact / decision / owner")
        canvas.setFont("ReviewCode", 7.8)
        canvas.drawString(36, 286, 'assert source_sha256 == frozen_source_sha256')
        canvas.setFont("ReviewSans", 7.2)
        canvas.drawString(36, 256, "[S1] Source locator and reference. https://example.org/proof")
        # Distinct corner marks catch rotation, clipping, and origin errors.
        for x, y, color in ((8, 8, (1, 0, 0)), (402, 8, (0, 1, 0)),
                            (8, 577, (0, 0, 1)), (402, 577, (1, 0, 1))):
            canvas.setFillColorRGB(*color)
            canvas.rect(x, y, 10, 10, fill=1, stroke=0)
        canvas.linkURL("https://example.org/proof", (36, 180, 220, 220),
                       relative=0, thickness=2, color=Color(1, 0, 0))
        canvas.showPage()
    canvas.save()
    writer = PdfWriter()
    reader = PdfReader(io.BytesIO(memory.getvalue()), strict=True)
    for index, page in enumerate(reader.pages):
        if index in (1, 2, 3):
            page.rotate(index * 90)
        if index == 4:
            page.add_transformation(Transformation().translate(30, 40))
            page.mediabox = RectangleObject((30, 40, 450, 634.96))
            page.cropbox = RectangleObject((30, 40, 450, 634.96))
            # The visible annotation is intentionally absent on the offset
            # page: changing content origin does not transform annotations.
            del page["/Annots"]
        if index == 5:
            page.cropbox = RectangleObject((20, 30, 400, 565))
        writer.add_page(page)
    with path.open("xb") as handle:
        writer.write(handle)


def metrics(left: Path, right: Path, dark: bool = False, *, legacy: bool = False) -> dict:
    with Image.open(left) as a, Image.open(right) as b:
        a, b = a.convert("RGB"), b.convert("RGB")
        original_sizes = [list(a.size), list(b.size)]
        if a.size != b.size:
            if not legacy:
                raise AssertionError(f"Image geometry mismatch: {a.size} != {b.size}")
            # Keep the old thumbnail's rounding defect visible; the common
            # extent is used only to measure the legacy font-weight control.
            common = (0, 0, min(a.width, b.width), min(a.height, b.height))
            a, b = a.crop(common), b.crop(common)
        mean = sum(ImageStat.Stat(ImageChops.difference(a, b)).mean) / 3
        def mask(image: Image.Image) -> Image.Image:
            return image.convert("L").point(lambda v: 255 if (v > 100 if dark else v < 140) else 0)
        ma, mb = mask(a), mask(b)
        outside_a = ImageChops.subtract(ma, mb.filter(ImageFilter.MaxFilter(5)))
        outside_b = ImageChops.subtract(mb, ma.filter(ImageFilter.MaxFilter(5)))
        unmatched = [ImageStat.Stat(outside_a).sum[0] / max(1, ImageStat.Stat(ma).sum[0]),
                     ImageStat.Stat(outside_b).sum[0] / max(1, ImageStat.Stat(mb).sum[0])]
        # Exclude the annotation and color marks for the weight comparison.
        # Page 1 only: regular and bold text plus the 7.2pt table/reference.
        crop = (70, 140, 780, 700)
        ga, gb = a.crop(crop).convert("L"), b.crop(crop).convert("L")
        if dark:
            mass_a = sum(max(0, value - 25) for value in ga.getdata())
            mass_b = sum(max(0, value - 25) for value in gb.getdata())
        else:
            mass_a = sum(255 - value for value in ga.getdata())
            mass_b = sum(255 - value for value in gb.getdata())
        return {"width": a.width, "height": a.height, "originalSizes": original_sizes,
                "meanAbsoluteRgbDifference": mean,
                "unmatchedInkOutsideTwoPixels": unmatched,
                "pdfkitToPopplerInkMassRatio": mass_a / mass_b if mass_b else None}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--renderer", type=Path, required=True)
    parser.add_argument("--legacy-renderer", type=Path)
    parser.add_argument("--fixture", type=Path, help="Reuse an existing immutable test fixture; creates no PDF")
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if platform.system() != "Darwin":
        raise SystemExit("PDFKit regression requires macOS; not a portable renderer pass")
    renderer = args.renderer.resolve(strict=True)
    poppler = shutil.which("pdftoppm")
    if not poppler or not os.access(renderer, os.X_OK):
        raise SystemExit("Executable PDFKit renderer and pdftoppm are required")
    output = fresh(args.output)
    report = {"schemaVersion": 1, "status": "failed", "releaseApproval": False,
              "renderer": str(renderer), "rendererSha256": digest(renderer),
              "sourceSha256": digest(TOOLKIT / "scripts/render-pdfkit.swift"),
              "checks": [], "commands": [], "limitations": [
                  "Synthetic and bounded regression evidence is not whole-book release approval.",
                  "No claim of pixel identity between independent renderers."]}

    def run(label: str, command: list[str], *, success: bool = True) -> subprocess.CompletedProcess:
        result = subprocess.run(command, capture_output=True, text=True, timeout=120)
        write(output / (label + ".log"), json.dumps(command) + "\n" + result.stdout + result.stderr)
        report["commands"].append({"label": label, "exitCode": result.returncode})
        if (result.returncode == 0) != success:
            raise AssertionError(f"{label}: expected success={success}, got exit {result.returncode}")
        return result

    try:
        if args.fixture:
            pdf = args.fixture.absolute()
            if any(p.is_symlink() for p in (pdf, *pdf.parents)) or not pdf.is_file():
                raise ValueError("Reused fixture must be a regular file without symlink ancestors")
        else:
            pdf = output / "raster-regression.pdf"
            fixture(pdf)
        before = digest(pdf)
        rendered = output / "pdfkit"
        result = run("pdfkit", [str(renderer), "--pdf", str(pdf), "--output-dir", str(rendered), "--dpi", "144"])
        receipt = json.loads(result.stdout)
        assert receipt["sourceSha256"] == before and receipt["fontSmoothing"] is False
        assert receipt["antialiasing"] is True and receipt["renderMethod"] == "PDFPage.draw(with:to:)"
        assert receipt["pages"] == 6 and len(receipt["pageImages"]) == 6
        report["checks"].append("direct drawing / explicit raster settings / exact source hash")
        poppler_dir = output / "poppler"
        poppler_dir.mkdir()
        run("poppler", [poppler, "-r", "144", "-png", str(pdf), str(poppler_dir / "page")])
        geometry = [(840, 1190), (1190, 840), (840, 1190), (1190, 840), (840, 1190), (840, 1190)]
        pages = []
        for index, size in enumerate(geometry, 1):
            left = rendered / f"page-{index:03d}.png"
            right = poppler_dir / f"page-{index}.png"
            measurement = metrics(left, right, dark=index == 6)
            assert (measurement["width"], measurement["height"]) == size
            assert measurement["meanAbsoluteRgbDifference"] < 5, measurement
            assert max(measurement["unmatchedInkOutsideTwoPixels"]) < 0.03, measurement
            entry = receipt["pageImages"][index - 1]
            assert entry["sha256"] == digest(left)
            pages.append({"page": index, **measurement})
        assert 0.92 < pages[0]["pdfkitToPopplerInkMassRatio"] < 1.08, pages[0]
        report["pages"] = pages
        report["checks"].extend(["regular/bold/table/code/reference weight (within 8% ink mass)",
                                 "0/90/180/270 rotation and full media box",
                                 "non-zero media-box origin and smaller crop box",
                                 "all six PNG hashes / dimensions / bounded independent-renderer difference",
                                 "bidirectional ink coverage within two pixels on all six pages"])
        # Annotation red border must remain visible in the unrotated first page.
        with Image.open(rendered / "page-001.png") as image:
            red = sum(r > 180 and g < 80 and b < 80 for r, g, b, *_ in image.crop((70, 746, 442, 832)).getdata())
        assert red > 500, red
        report["checks"].append("visible PDF annotation retained")
        if args.legacy_renderer:
            legacy = args.legacy_renderer.resolve(strict=True)
            run("legacy-control", [str(legacy), "--pdf", str(pdf), "--output-dir", str(output / "legacy"), "--dpi", "144"])
            report["legacyPage1"] = metrics(output / "legacy/page-001.png", poppler_dir / "page-1.png", legacy=True)
        existing = output / "existing"
        existing.mkdir()
        write(existing / "page-001.png", "must be preserved")
        empty = output / "existing-empty"
        empty.mkdir()
        file_target = output / "existing-file"
        write(file_target, "must be preserved")
        link = output / "output-link"
        link.symlink_to(existing, target_is_directory=True)
        dangling = output / "dangling-link"
        dangling.symlink_to(output / "absent")
        linked_pdf = output / "input-link.pdf"
        linked_pdf.symlink_to(pdf)
        invalid_pdf = output / "invalid.pdf"
        write(invalid_pdf, "not a PDF")
        targets = [("existing-output", existing), ("existing-empty", empty),
                   ("file-output", file_target), ("output-symlink", link),
                   ("dangling-symlink", dangling), ("ancestor-symlink", link / "new")]
        for label, target in targets:
            run("reject-" + label, [str(renderer), "--pdf", str(pdf), "--output-dir", str(target)], success=False)
        for value in ("junk", "nan", "inf", "71", "601"):
            run("reject-dpi-" + value, [str(renderer), "--pdf", str(pdf), "--output-dir", str(output / ("invalid-dpi-" + value)), "--dpi", value], success=False)
        for label, source in (("symlink-input", linked_pdf), ("invalid-input", invalid_pdf), ("directory-input", existing)):
            run("reject-" + label, [str(renderer), "--pdf", str(source), "--output-dir", str(output / (label + "-out"))], success=False)
        base = [str(renderer), "--pdf", str(pdf), "--output-dir", str(output / "invalid-arguments")]
        for label, tail in (("duplicate", ["--dpi", "144", "--dpi", "72"]),
                            ("missing", ["--dpi"]), ("unknown", ["--cropbox", "true"])):
            run("reject-" + label, base + tail, success=False)
        run("reject-parent-traversal", [str(renderer), "--pdf", str(pdf), "--output-dir", str(output / "existing/../parent-traversal")], success=False)
        assert digest(pdf) == before and (existing / "page-001.png").read_text() == "must be preserved"
        assert file_target.read_text() == "must be preserved" and not list(empty.iterdir())
        assert not (existing / "new").exists()
        report["negativeCases"] = 18
        report["checks"].append("18 negative CLI/output/input cases; all existing evidence preserved")
        report["fixture"] = {"path": str(pdf), "sha256": before, "unchanged": True}
        assert report["sourceSha256"] == digest(TOOLKIT / "scripts/render-pdfkit.swift")
        report["status"] = "passed"
    except Exception as error:
        report["error"] = f"{type(error).__name__}: {error}"
    write(output / "pdfkit-regression.json", json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))
    return 0 if report["status"] == "passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
