"""Shared semantic rule: only chapter openings may display an eyebrow."""
from reportlab.platypus import Spacer

CHAPTER_MARKER = 'chapter-marker'
LEGACY_EYEBROW_STYLES = frozenset({'CoverKicker', 'ChapterKicker', 'TOCKicker'})


def is_eyebrow(style):
    return bool(getattr(style, 'handbookEyebrow', False) or style.name in LEGACY_EYEBROW_STYLES)


def suppress_eyebrow(style, role=None):
    if role is not None and role != CHAPTER_MARKER:
        raise ValueError(f'Unsupported handbook paragraph role: {role}')
    if role == CHAPTER_MARKER and not is_eyebrow(style):
        raise ValueError('A chapter marker requires an eyebrow style')
    return is_eyebrow(style) and role != CHAPTER_MARKER


class OmittedEyebrow(Spacer):
    """Retain source intent without painting a label or reserving its space."""
    def __init__(self):
        super().__init__(0, 0)


def visible_paragraph(paragraph):
    return not suppress_eyebrow(paragraph.style, getattr(paragraph, '_handbook_role', None))


from functools import lru_cache

@lru_cache(maxsize=16)
def _painted_baseline_lines(book, released_pdf, released_sha256):
    from pdf_baseline import load_baseline
    _, reader = load_baseline(book, {'baselineMode':'appearance-companion',
                                    'releasedPdf':released_pdf,
                                    'releasedSha256':released_sha256})
    return frozenset(' '.join(line.split()) for page in reader.pages
                     for line in (page.extract_text() or '').splitlines())


def retained_appearance_style(style, role, baseline_mode, *, text, book, config):
    """Preserve only labels actually painted by the verified retained edition."""
    if baseline_mode != 'appearance-companion' or role is not None or not is_eyebrow(style):
        return style
    import html, re
    label = ' '.join(html.unescape(re.sub('<[^>]*>', '', text)).split())
    painted = _painted_baseline_lines(str(book), config.get('releasedPdf'), config.get('releasedSha256'))
    if label in painted:
        from reportlab.lib.styles import ParagraphStyle
        return ParagraphStyle('RetainedAppearanceLabel', parent=style, handbookEyebrow=False)
    return style
