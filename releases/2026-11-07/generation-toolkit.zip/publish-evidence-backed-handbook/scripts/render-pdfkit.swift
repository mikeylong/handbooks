#!/usr/bin/env swift
import AppKit
import CryptoKit
import Darwin
import Foundation
import PDFKit

func fail(_ message: String) -> Never {
    FileHandle.standardError.write(Data((message + "\n").utf8))
    exit(1)
}

func checkedPath(_ argument: String, label: String) -> URL {
    let expanded = NSString(string: argument).expandingTildeInPath
    guard !expanded.split(separator: "/").contains("..") else {
        fail("\(label) cannot contain parent traversal")
    }
    let url = URL(fileURLWithPath: expanded).standardizedFileURL
    var component = url
    while component.path != "/" {
        do {
            let values = try component.resourceValues(forKeys: [.isSymbolicLinkKey])
            guard values.isSymbolicLink != true else { fail("\(label) cannot traverse a symlink: \(component.path)") }
        } catch {
            // A new output and some of its parents may not exist yet. Other
            // errors (permissions, unreadable parents) must not be ignored.
            let nsError = error as NSError
            guard nsError.domain == NSCocoaErrorDomain && nsError.code == NSFileReadNoSuchFileError else {
                fail("Unable to inspect \(label): \(error)")
            }
        }
        component.deleteLastPathComponent()
    }
    return url
}

func sha256(_ data: Data) -> String {
    SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
}

var arguments: [String: String] = [:]
var argumentIndex = 1
while argumentIndex < CommandLine.arguments.count {
    let name = CommandLine.arguments[argumentIndex]
    guard ["--pdf", "--output-dir", "--dpi"].contains(name),
          arguments[name] == nil, argumentIndex + 1 < CommandLine.arguments.count,
          !CommandLine.arguments[argumentIndex + 1].hasPrefix("--") else {
        fail("Unknown, duplicate, or incomplete argument: \(name)")
    }
    arguments[name] = CommandLine.arguments[argumentIndex + 1]
    argumentIndex += 2
}
guard let pdfArgument = arguments["--pdf"], let outputArgument = arguments["--output-dir"] else {
    fail("Usage: render-pdfkit.swift --pdf <file.pdf> --output-dir <directory> [--dpi <72-600>]")
}

guard let dpi = Double(arguments["--dpi"] ?? "144"), dpi.isFinite, dpi >= 72, dpi <= 600 else {
    fail("--dpi must be between 72 and 600")
}

let fileManager = FileManager.default
let pdfURL = checkedPath(pdfArgument, label: "PDF")
let outputURL = checkedPath(outputArgument, label: "Output directory")
guard (try? pdfURL.resourceValues(forKeys: [.isRegularFileKey]).isRegularFile) == true else {
    fail("PDF must be an existing regular file")
}
guard !fileManager.fileExists(atPath: outputURL.path) else {
    fail("Output directory must be fresh and must not already exist")
}
guard let sourceData = try? Data(contentsOf: pdfURL) else { fail("Unable to read PDF") }
let sourceSha256 = sha256(sourceData)
guard let document = PDFDocument(data: sourceData) else { fail("Unable to open PDF") }
guard !document.isLocked && document.pageCount > 0 else { fail("PDF is locked or has no pages") }
do { try fileManager.createDirectory(at: outputURL.deletingLastPathComponent(), withIntermediateDirectories: true) }
catch { fail("Unable to create fresh output directory: \(error)") }
// mkdir is exclusive: another process cannot turn the freshness check above
// into permission to reuse its existing directory, even if it is still empty.
_ = checkedPath(outputURL.path, label: "Output directory")
guard Darwin.mkdir(outputURL.path, mode_t(0o755)) == 0 else {
    fail("Unable to exclusively create fresh output directory (errno \(errno))")
}
var renderedPages: [[String: Any]] = []

for index in 0..<document.pageCount {
    guard let page = document.page(at: index) else { fail("Missing PDF page \(index + 1)") }
    let bounds = page.bounds(for: .mediaBox)
    let rotation = ((page.rotation % 360) + 360) % 360
    guard [0, 90, 180, 270].contains(rotation), bounds.width.isFinite, bounds.height.isFinite,
          bounds.width > 0, bounds.height > 0 else { fail("Invalid media box or rotation on page \(index + 1)") }
    let scale = dpi / 72.0
    let turned = rotation == 90 || rotation == 270
    let width = ceil((turned ? bounds.height : bounds.width) * scale)
    let height = ceil((turned ? bounds.width : bounds.height) * scale)
    guard width <= 32768, height <= 32768, width * height <= 100_000_000 else {
        fail("Page \(index + 1) exceeds the raster safety limit")
    }
    guard let colorSpace = CGColorSpace(name: CGColorSpace.sRGB),
          let context = CGContext(data: nil, width: Int(width), height: Int(height), bitsPerComponent: 8,
                                  bytesPerRow: 0, space: colorSpace,
                                  bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else {
        fail("Unable to allocate page \(index + 1)")
    }
    // PDFKit's thumbnail/NSImage/TIFF path applies display-oriented font
    // smoothing, visibly emboldening the same embedded font. Render straight
    // into an sRGB bitmap, retaining grayscale edge antialiasing, not LCD/font
    // smoothing. PDFPage.draw handles page rotation, media-box origins and
    // annotations itself. Do not concatenate a second page transform.
    context.setFillColor(CGColor(gray: 1, alpha: 1))
    context.fill(CGRect(x: 0, y: 0, width: width, height: height))
    context.setAllowsAntialiasing(true)
    context.setShouldAntialias(true)
    context.setAllowsFontSmoothing(false)
    context.setShouldSmoothFonts(false)
    context.interpolationQuality = .high
    context.scaleBy(x: scale, y: scale)
    page.draw(with: .mediaBox, to: context)
    guard let image = context.makeImage(),
          let png = NSBitmapImageRep(cgImage: image).representation(using: .png, properties: [:]) else {
        fail("Unable to encode PDF page \(index + 1)")
    }
    let name = String(format: "page-%03d.png", index + 1)
    // Exclusive writes preserve evidence if another process creates a target.
    do { try png.write(to: outputURL.appendingPathComponent(name), options: .withoutOverwriting) }
    catch { fail("Unable to write fresh page \(index + 1): \(error)") }
    renderedPages.append(["page": index + 1, "file": name, "width": Int(width), "height": Int(height),
                          "rotation": rotation, "sha256": sha256(png)])
}
guard let finalSource = try? Data(contentsOf: pdfURL), sha256(finalSource) == sourceSha256 else {
    fail("PDF changed during rendering")
}

let report: [String: Any] = [
    "schemaVersion": 2,
    "status": "passed",
    "renderer": "Apple PDFKit",
    "pdf": pdfURL.lastPathComponent,
    "pages": document.pageCount,
    "dpi": dpi,
    "outputDirectory": outputURL.lastPathComponent,
    "sourceSha256": sourceSha256,
    "renderMethod": "PDFPage.draw(with:to:)",
    "colorSpace": "sRGB",
    "fontSmoothing": false,
    "antialiasing": true,
    "displayBox": "mediaBox",
    "pageImages": renderedPages
]
let reportData = try JSONSerialization.data(withJSONObject: report, options: [.prettyPrinted, .sortedKeys])
FileHandle.standardOutput.write(reportData)
FileHandle.standardOutput.write(Data("\n".utf8))
