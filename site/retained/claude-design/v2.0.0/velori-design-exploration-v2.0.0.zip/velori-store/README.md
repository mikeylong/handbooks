# Velori design exploration exercise

Explore alternatives for reviewing a configured robot, select a direction, refine it in Claude Design and review the connected journey. Finish with an interactive prototype and a handoff the recipient can open.

## Choose the input

1. Figma-first: use `velori-design-exploration-starter.fig`. The starter retains Foundations, Components, Configurator and Source Assets; the completed Store exercise page is excluded. Import into your own Figma Drafts if you want to inspect or work there. Attach the starter to your own private Design system setup with product context and required licensed fonts.
2. Code-first: use `src/library.jsx`, tokens, styles, product assets and baseline guidance. Use Claude Code `/design-sync` from your own project. Exclude the completed review implementation and answer-key guidance from initial generation context.

The app source includes a completed answer for later comparison. Keep it out of initial context. The starter does not bundle font software; supply licensed fonts or record substitutions. Unused Store state variables inherited from the companion may remain; the completed Store layouts were removed.

## Run the answer after choosing your direction

```sh
npm ci
npm run dev
```

Use Node.js 22 and the Vite address printed by the command (default port 4197). The first install requires npm access. The local answer does not need a Claude or Figma account.

## Complete the design task

Follow `docs/prompts.md` and record the actual run in `docs/walkthrough.md`. Use Graphite, Simple, Amber and Carry bag. Check browse-versus-select behavior, review/edit continuity, an unavailable state and a narrow viewport. Complete the main Design review before choosing Code implementation or continued Figma design.

## Requirements and completion

Use your own authorized Claude Design account and organization. Figma work requires an account and edit access to your copy. Code work requires Claude Code and a runnable project. No author-private organization or Figma file is required. Native variable-driven Figma prototypes may require additional plan features; they are not a requirement for the main Design exercise.

This is an unapproved candidate package. The recorded Figma-first trial produced three alternatives, a selected connected prototype and native exports. A fresh recipient opening verified the standalone HTML, keyboard changes and reload retention. Direct edits did not save for the tested file; chat supplied the verified fallback. Human review remains open. Original and third-party notices remain with the material.

## Compare the recorded answer

Open `answer-key/velori-review-prototype.html` directly or serve this folder locally. It embeds scripts and photos and does not require the author’s account. Prototype controls deliberately stage unavailability and image errors. Offline Retry reloads bundled images, not a failed network request. Import `answer-key/velori-review-continuation.fig` into your own Figma Drafts for editable static Review work. The four source pages remain; the new page has restored instances, styles and variables, with no prototype or state wiring. Keep both answers out of the initial upload.
