# Expected results

1. The starting context excludes the completed review layout.
2. Two or three directions expose different hierarchies or editing approaches.
3. One direction is selected with reasons, refined, and used on connected screens.
4. Graphite, Simple, Amber and Carry bag remain consistent through details, review and edit. Browsing Charging dock does not silently select it.
5. Unavailable imagery keeps the choices and recovery actions usable. Distinguish a simulated state from a tested request failure.
6. A narrow view and keyboard journey are checked. A person can complete the review task.
7. The recipient opens the exported prototype and understands decisions and limitations.
8. Any chosen Code implementation or Figma continuation has its own checks.
