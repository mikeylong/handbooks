# Selected design handoff

1. Recipient and next task.
2. Selected prototype/files and opening instructions.
3. Source system and component context.
4. Selection rationale and accepted tradeoffs.
5. Fixture, states, transitions and responsive priorities.
6. Prototype-only shortcuts and unresolved issues.
7. Required assets, dependencies and account/network access.
8. Actual recipient opening result.
9. Implementation deviations or Figma relationships to restore.
