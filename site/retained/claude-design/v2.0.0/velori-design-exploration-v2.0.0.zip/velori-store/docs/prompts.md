# Design exploration prompts

Use the prompts in order, selecting the preparation route that matches your source. Record returned files and actual results.

## 1

```text
A Velori shopper has configured a robot and wants to check the choices before confirming. Explore alternatives for reviewing that configuration and returning to edit. Preserve the product identity, real imagery, finish, face, expression color and one-accessory rule. Compare hierarchy and editing approaches. Do not add checkout or imply that an order has been placed.
```

## 2

```text
Compare this starting screen with the supplied Velori configurator. Check the brand, heading, choice groups, expression menu, selected marks, button and configured product image. Name mismatches and missing source material. Correct the source rule for each mismatch before proposing the new review screen.
```

## 3

```text
Explore three directions for reviewing a configured Velori robot. A: a compact summary beside the product. B: a dedicated review screen with clear edit links. C: a guided review that groups the choices. Keep the same choices, product imagery and visual language. Make the differences about hierarchy and interaction. Label and retain each direction so we can compare them before refining one.
```

## 4

```text
Refine direction B. Keep review separate from configuration. Put the four choices in a scannable summary and place an Edit configuration action beside them. On narrow screens, show the summary before secondary product details. Preserve selected values when returning to the configurator.
```

## 5

```text
Connect the selected review direction to the supplied configurator and accessory details. Configure opens Review configuration. Edit returns to Configure with the choices retained. Browsing Charging dock details while Carry bag is selected must keep Carry bag selected until the shopper explicitly changes the choice. Keep the product image, caption and summary consistent across the journey.
```

## 6

```text
Implement the selected Velori review direction in this product project. Inspect the existing components, tokens and state ownership before changing code. Preserve the configurator, product assets and four choices. Map the design to the maintained library. Keep configure, details, review and edit consistent. Explain necessary adaptations and test the interactive journey, keyboard behavior and narrow layout.
```
