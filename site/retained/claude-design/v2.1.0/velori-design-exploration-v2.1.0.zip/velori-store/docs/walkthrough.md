# Run record

This worksheet records a fresh Design exercise. Historical answers do not complete this run.

| Item | Record from your run |
|---|---|
| Surface/account/organization | |
| Input route and filenames | |
| Private destination/system | |
| Import gaps and corrections | |
| Alternatives and selected file | |
| Rationale and accepted tradeoff | |
| Chat refinement | |
| Targeted comment/result | |
| Direct edit/result | |
| Configure/details/review/edit | |
| Unavailable state and narrow view | |
| Human review and keyboard result | |
| Export and recipient opening | |
| Chosen Code/Figma continuation | |
| Remaining High/Medium/Low issues | |

Main completion: reviewed interactive prototype and recipient-usable handoff. Destination completion: separate implementation or Figma editability checks when requested.


## Updated exercise endpoint

Complete Configure → Review → Add to cart → Cart confirmation. The cart contains one configured robot with all four choices and quantity one. Edit cart item restores its choices; adding again updates the item without duplication. Payment and order submission remain outside the task. See `add-to-cart.md` for the revised behavior and the scope of the retained trial evidence.
