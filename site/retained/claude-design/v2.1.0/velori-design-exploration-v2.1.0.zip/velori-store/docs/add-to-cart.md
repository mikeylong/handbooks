# Add to cart exercise revision

Finish the shopper journey: Configure → Review → Add to cart → Cart confirmation.

The cart shows one Velori personal robot, its image, finish, face, expression color, accessory and quantity one. Edit cart item restores these choices. Add again updates that item; repeated activation never creates a duplicate. The item remains after a same-session reload. Empty cart returns to configuration. A staged unavailable accessory must be changed before adding.

Payment, shipping, taxes and order submission are outside this exercise. The cart is a local teaching prototype, not a store transaction.

Open `answer-key/velori-review-prototype.html` in a browser. Begin with Graphite, Simple, Amber and Carry bag. Continue to Review, then Add to cart. Use Edit cart item, change a choice, review and add again. Check the image and summary agree.

This October 7 extension was implemented locally from the October 6 Claude Design HTML export. The recorded native trial and Figma continuation remain historical evidence of the earlier Review direction. They do not establish native generation of this new cart step.

The configurator action is labeled Continue both when starting and when editing. Reset fixture restores its starting choices, clears the teaching cart and opens Configure.
